package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.dp

enum class VisualThemeMode(
    val displayName: String,
    val subtitle: String,
    val isDark: Boolean
) {
    CELESTIAL_ASTROLABE(
        displayName = "深宇宙・天体観測",
        subtitle = "星金と軌道線の天体儀スタイル",
        isDark = true
    ),
    PARCHMENT_MAP(
        displayName = "羊皮紙・古地図",
        subtitle = "セピアと等高線の旅人地図",
        isDark = false
    ),
    GEOMETRIC_MINIMAL(
        displayName = "ジオメトリック",
        subtitle = "明快で洗練された構成図スタイル",
        isDark = false
    ),
    RETRO_PIXEL(
        displayName = "レトロドット箱庭",
        subtitle = "16bit風ブロックと高コントラスト",
        isDark = true
    )
}

val LocalVisualThemeMode = staticCompositionLocalOf { VisualThemeMode.CELESTIAL_ASTROLABE }

private fun shapesForTheme(mode: VisualThemeMode): Shapes = when (mode) {
    VisualThemeMode.RETRO_PIXEL -> Shapes(
        extraSmall = RoundedCornerShape(2.dp),
        small = RoundedCornerShape(2.dp),
        medium = RoundedCornerShape(4.dp),
        large = RoundedCornerShape(4.dp),
        extraLarge = RoundedCornerShape(6.dp)
    )
    VisualThemeMode.GEOMETRIC_MINIMAL -> Shapes(
        extraSmall = RoundedCornerShape(4.dp),
        small = RoundedCornerShape(8.dp),
        medium = RoundedCornerShape(12.dp),
        large = RoundedCornerShape(16.dp),
        extraLarge = RoundedCornerShape(24.dp)
    )
    else -> Shapes(
        extraSmall = RoundedCornerShape(6.dp),
        small = RoundedCornerShape(10.dp),
        medium = RoundedCornerShape(14.dp),
        large = RoundedCornerShape(20.dp),
        extraLarge = RoundedCornerShape(28.dp)
    )
}

@Composable
fun HoshitsumugiTheme(
    themeMode: VisualThemeMode = VisualThemeMode.CELESTIAL_ASTROLABE,
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeMode) {
        VisualThemeMode.CELESTIAL_ASTROLABE -> CelestialColorScheme
        VisualThemeMode.PARCHMENT_MAP -> ParchmentColorScheme
        VisualThemeMode.GEOMETRIC_MINIMAL -> GeometricColorScheme
        VisualThemeMode.RETRO_PIXEL -> RetroPixelColorScheme
    }

    CompositionLocalProvider(LocalVisualThemeMode provides themeMode) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = typographyForTheme(themeMode),
            shapes = shapesForTheme(themeMode),
            content = content
        )
    }
}
