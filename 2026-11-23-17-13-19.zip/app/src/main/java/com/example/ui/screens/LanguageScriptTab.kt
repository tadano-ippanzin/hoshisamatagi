package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.engine.ProceduralGenerator
import com.example.model.GenerationMode
import com.example.model.GlyphDefinition
import com.example.model.Language
import com.example.model.WorldBundle
import com.example.model.WorldCodecs
import com.example.ui.components.GlyphCanvasView
import com.example.ui.components.GlyphEditorDialog

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LanguageScriptTab(
    bundle: WorldBundle,
    generationMode: GenerationMode,
    isGenerating: Boolean,
    onCreateLanguage: (GenerationMode, String) -> Unit,
    onSaveLanguage: (Language) -> Unit,
    onUpdateGlyph: (Language, GlyphDefinition) -> Unit,
    onAddWord: (Language, String, String) -> Unit,
    onDeleteEntity: (String, String) -> Unit
) {
    var editingGlyphPair by remember { mutableStateOf<Pair<Language, GlyphDefinition>?>(null) }
    var addingWordLang by remember { mutableStateOf<Language?>(null) }
    var editingLang by remember { mutableStateOf<Language?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { onCreateLanguage(generationMode, "") },
                    enabled = !isGenerating,
                    modifier = Modifier.weight(1f).testTag("create_language_button")
                ) {
                    Icon(Icons.Filled.Translate, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("${generationMode.shortLabel}で言語と文字を創る")
                }
            }
        }

        if (bundle.languages.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("まだ言語・独自文字がありません", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "上のボタンから音韻体系・語順・語彙辞書と、手描き編集可能な独自文字グリフセットを創造できます。",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        items(bundle.languages, key = { it.id }) { lang ->
            val glyphs = remember(lang.glyphStrokes) {
                lang.glyphStrokes.mapNotNull { WorldCodecs.decodeGlyph(it) }
            }
            val glyphLookup = remember(glyphs) { glyphs.associateBy { it.symbolKey.lowercase() } }

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${lang.name} / ${lang.scriptName}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "語順:${lang.wordOrder} ・ 音節:${lang.syllablePattern} ・ ${lang.scriptType}(${lang.writingDirection})",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(
                            onClick = { editingLang = lang },
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(Icons.Filled.Edit, contentDescription = "言語を編集")
                        }
                        IconButton(
                            onClick = { onDeleteEntity("languages", lang.id) },
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(Icons.Filled.Delete, contentDescription = "${lang.name}を削除")
                        }
                    }

                    Text(
                        text = "母音 [${lang.vowels}] ・ 子音 [${lang.consonants}]",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // Live Script Signboard rendering sampleSentence in custom glyphs!
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "独自文字プレビュー「${lang.sampleSentence}」",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            val chars = lang.sampleSentence.lowercase().filter { !it.isWhitespace() }.take(18)
                            val orderedChars = if (lang.writingDirection == "RTL") chars.reversed() else chars
                            if (lang.writingDirection == "TTB") {
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    orderedChars.chunked(6).forEach { colChunk ->
                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            colChunk.forEach { ch ->
                                                val g = glyphLookup[ch.toString()]
                                                    ?: glyphs.getOrNull(ch.code % glyphs.size.coerceAtLeast(1))
                                                if (g != null) {
                                                    GlyphCanvasView(
                                                        glyph = g,
                                                        modifier = Modifier.size(26.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            } else {
                                Row(
                                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    orderedChars.forEach { ch ->
                                        val g = glyphLookup[ch.toString()]
                                            ?: glyphs.getOrNull(ch.code % glyphs.size.coerceAtLeast(1))
                                        if (g != null) {
                                            GlyphCanvasView(
                                                glyph = g,
                                                modifier = Modifier.size(28.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Interactive Glyph Palette (Tap any glyph to draw/edit strokes!)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "文字グリフ一覧（タップで手描き編集）",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                        TextButton(onClick = {
                            val newKey = "g${glyphs.size + 1}"
                            editingGlyphPair = lang to ProceduralGenerator.generateProceduralGlyph(newKey)
                        }) {
                            Icon(Icons.Filled.Draw, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("新文字を描く")
                        }
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        glyphs.forEach { g ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clip(MaterialTheme.shapes.small)
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f))
                                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), MaterialTheme.shapes.small)
                                    .clickable { editingGlyphPair = lang to g }
                                    .padding(6.dp)
                                    .testTag("glyph_tile_${g.symbolKey}")
                            ) {
                                GlyphCanvasView(glyph = g, modifier = Modifier.size(34.dp))
                                Text(g.symbolKey, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }

                    HorizontalDivider()

                    // Lexicon Dictionary
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "語彙辞書 (${lang.lexiconEntries.size}語)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                        OutlinedButton(
                            onClick = { addingWordLang = lang },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("単語を追加")
                        }
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        lang.lexiconEntries.forEach { entry ->
                            val (w, m) = WorldCodecs.decodeLexiconEntry(entry)
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                                shape = MaterialTheme.shapes.small
                            ) {
                                Text(
                                    text = "$w : $m",
                                    style = MaterialTheme.typography.labelMedium,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    editingGlyphPair?.let { (lang, glyph) ->
        GlyphEditorDialog(
            initialGlyph = glyph,
            onDismiss = { editingGlyphPair = null },
            onSave = { updatedGlyph ->
                onUpdateGlyph(lang, updatedGlyph)
                editingGlyphPair = null
            }
        )
    }

    addingWordLang?.let { lang ->
        var wordInput by remember { mutableStateOf("") }
        var meaningInput by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { addingWordLang = null },
            title = { Text("${lang.name}に単語を追加") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = wordInput,
                        onValueChange = { wordInput = it },
                        label = { Text("単語（空欄なら音韻法則で自動造語）") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = meaningInput,
                        onValueChange = { meaningInput = it },
                        label = { Text("意味（例: 海、誓い、星船）") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    onAddWord(lang, wordInput, meaningInput)
                    addingWordLang = null
                }) { Text("登録") }
            },
            dismissButton = { TextButton(onClick = { addingWordLang = null }) { Text("閉じる") } }
        )
    }

    editingLang?.let { lang ->
        var name by remember { mutableStateOf(lang.name) }
        var scriptName by remember { mutableStateOf(lang.scriptName) }
        var wordOrder by remember { mutableStateOf(lang.wordOrder) }
        var dir by remember { mutableStateOf(lang.writingDirection) }
        var sample by remember { mutableStateOf(lang.sampleSentence) }

        AlertDialog(
            onDismissRequest = { editingLang = null },
            title = { Text("言語と文字体系の設定") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("言語名") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = scriptName, onValueChange = { scriptName = it }, label = { Text("文字名") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Text("語順", style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("SOV", "SVO", "VSO").forEach { wo ->
                            FilterChip(selected = wordOrder == wo, onClick = { wordOrder = wo }, label = { Text(wo) })
                        }
                    }
                    Text("書字方向", style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("LTR", "RTL", "TTB").forEach { d ->
                            FilterChip(selected = dir == d, onClick = { dir = d }, label = { Text(d) })
                        }
                    }
                    OutlinedTextField(value = sample, onValueChange = { sample = it }, label = { Text("例文・挨拶") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(onClick = {
                    onSaveLanguage(lang.copy(name = name, scriptName = scriptName, wordOrder = wordOrder, writingDirection = dir, sampleSentence = sample))
                    editingLang = null
                }) { Text("保存") }
            },
            dismissButton = { TextButton(onClick = { editingLang = null }) { Text("閉じる") } }
        )
    }
}
