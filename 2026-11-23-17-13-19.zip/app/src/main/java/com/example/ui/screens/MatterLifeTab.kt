package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Science
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.BiomeType
import com.example.model.Ecosystem
import com.example.model.GenerationMode
import com.example.model.Species
import com.example.model.WorldBundle
import com.example.model.WorldElement

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MatterLifeTab(
    bundle: WorldBundle,
    generationMode: GenerationMode,
    isGenerating: Boolean,
    onCreateElement: (GenerationMode, String) -> Unit,
    onSaveElement: (WorldElement) -> Unit,
    onSynthesizeElements: (WorldElement, WorldElement) -> Unit,
    onCreateEcosystem: (GenerationMode, String) -> Unit,
    onCreateSpecies: (String, String) -> Unit,
    onDeleteEntity: (String, String) -> Unit
) {
    var subTab by remember { mutableIntStateOf(0) } // 0 = 元素, 1 = 生態系・生物
    var showCreateElementDialog by remember { mutableStateOf(false) }
    var showSynthDialog by remember { mutableStateOf(false) }
    var showCreateEcoDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = subTab) {
            Tab(
                selected = subTab == 0,
                onClick = { subTab = 0 },
                text = { Text("元素・合成 (${bundle.elements.size})") },
                icon = { Icon(Icons.Filled.Science, contentDescription = null) }
            )
            Tab(
                selected = subTab == 1,
                onClick = { subTab = 1 },
                text = { Text("生態系・生物 (${bundle.ecosystems.size}/${bundle.species.size})") },
                icon = { Icon(Icons.Filled.Pets, contentDescription = null) }
            )
        }

        if (subTab == 0) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onCreateElement(generationMode, "") },
                            enabled = !isGenerating,
                            modifier = Modifier.weight(1f).testTag("quick_create_element_button")
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("${generationMode.shortLabel}で元素生成")
                        }
                        OutlinedButton(
                            onClick = { showCreateElementDialog = true },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("手動で定義")
                        }
                    }
                    if (bundle.elements.size >= 2) {
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { showSynthDialog = true },
                            modifier = Modifier.fillMaxWidth().testTag("open_synthesizer_button")
                        ) {
                            Icon(Icons.Filled.Science, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("2つの元素を合成して新物質を作る")
                        }
                    }
                }

                items(bundle.elements, key = { it.id }) { el ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(MaterialTheme.shapes.medium)
                                    .background(Color(el.colorHex).copy(alpha = 0.25f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = el.symbol,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(el.colorHex)
                                    )
                                    Text(
                                        text = "#${el.atomicNumber}",
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(el.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                    Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = MaterialTheme.shapes.extraSmall) {
                                        Text(
                                            text = el.category,
                                            style = MaterialTheme.typography.labelSmall,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                if (el.compoundFormula.isNotBlank()) {
                                    Text("化学式: ${el.compoundFormula}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                }
                                Text(
                                    text = "揮発性 ${el.volatility}% ・ 存在比 ${el.abundance}%",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (el.traits.isNotBlank()) {
                                    Text(el.traits, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            IconButton(
                                onClick = { onDeleteEntity("elements", el.id) },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(Icons.Filled.Delete, contentDescription = "${el.name}を削除")
                            }
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Button(
                        onClick = { showCreateEcoDialog = true },
                        enabled = !isGenerating,
                        modifier = Modifier.fillMaxWidth().testTag("create_ecosystem_button")
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("${generationMode.shortLabel}で新しい生態系を創る")
                    }
                }

                items(bundle.ecosystems, key = { it.id }) { eco ->
                    val ecoSpecies = bundle.species.filter { it.ecosystemId == eco.id }
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(eco.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = "${eco.biomeType} ・ ${eco.climate} ・ 安定度 ${eco.stability}%",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                IconButton(
                                    onClick = { onDeleteEntity("ecosystems", eco.id) },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(Icons.Filled.Delete, contentDescription = "${eco.name}を削除")
                                }
                            }
                            if (eco.foodWebSummary.isNotBlank()) {
                                Text(eco.foodWebSummary, style = MaterialTheme.typography.bodySmall)
                            }
                            if (eco.keyResource.isNotBlank()) {
                                Text("基盤元素: ${eco.keyResource}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                            }

                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                ecoSpecies.forEach { sp ->
                                    Surface(
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        shape = MaterialTheme.shapes.small
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(start = 8.dp, top = 4.dp, bottom = 4.dp, end = 4.dp)
                                        ) {
                                            Text(
                                                text = "${sp.name}（${sp.trophicRole}・${sp.population}体）",
                                                style = MaterialTheme.typography.labelMedium
                                            )
                                            IconButton(
                                                onClick = { onDeleteEntity("species", sp.id) },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(Icons.Filled.Delete, contentDescription = "生物を削除", modifier = Modifier.size(14.dp))
                                            }
                                        }
                                    }
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("生産者", "草食", "肉食", "分解者").forEach { role ->
                                    OutlinedButton(
                                        onClick = { onCreateSpecies(eco.id, role) },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text("+ $role", style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateElementDialog) {
        var eName by remember { mutableStateOf("") }
        var eSym by remember { mutableStateOf("St") }
        var eCat by remember { mutableStateOf("結晶") }
        var eTraits by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreateElementDialog = false },
            title = { Text("元素を手動定義") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = eName, onValueChange = { eName = it }, label = { Text("元素名") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = eSym, onValueChange = { eSym = it }, label = { Text("記号") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = eCat, onValueChange = { eCat = it }, label = { Text("分類（金属/結晶/気体/霊素など）") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = eTraits, onValueChange = { eTraits = it }, label = { Text("特徴・用途") }, maxLines = 3, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(onClick = {
                    onSaveElement(
                        WorldElement(
                            name = eName.ifBlank { "新元素" },
                            symbol = eSym.ifBlank { "Nw" },
                            atomicNumber = (bundle.elements.size + 1).toLong(),
                            category = eCat.ifBlank { "基礎元素" },
                            traits = eTraits
                        )
                    )
                    showCreateElementDialog = false
                }) { Text("作成") }
            },
            dismissButton = { TextButton(onClick = { showCreateElementDialog = false }) { Text("閉じる") } }
        )
    }

    if (showSynthDialog && bundle.elements.size >= 2) {
        var first by remember { mutableStateOf(bundle.elements[0]) }
        var second by remember { mutableStateOf(bundle.elements[1]) }
        AlertDialog(
            onDismissRequest = { showSynthDialog = false },
            title = { Text("元素合成（化合物・合金）") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("元素1を選択", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        bundle.elements.forEach { el ->
                            FilterChip(selected = first.id == el.id, onClick = { first = el }, label = { Text("${el.symbol} ${el.name}") })
                        }
                    }
                    Text("元素2を選択", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        bundle.elements.forEach { el ->
                            FilterChip(selected = second.id == el.id, onClick = { second = el }, label = { Text("${el.symbol} ${el.name}") })
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    onSynthesizeElements(first, second)
                    showSynthDialog = false
                }) { Text("合成する") }
            },
            dismissButton = { TextButton(onClick = { showSynthDialog = false }) { Text("戻る") } }
        )
    }

    if (showCreateEcoDialog) {
        var chosenBiome by remember { mutableStateOf(BiomeType.FOREST.label) }
        AlertDialog(
            onDismissRequest = { showCreateEcoDialog = false },
            title = { Text("生態系を生成するバイオーム") },
            text = {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    BiomeType.entries.forEach { b ->
                        FilterChip(
                            selected = chosenBiome == b.label,
                            onClick = { chosenBiome = b.label },
                            label = { Text(b.label) }
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    onCreateEcosystem(generationMode, chosenBiome)
                    showCreateEcoDialog = false
                }) { Text("創生する") }
            },
            dismissButton = { TextButton(onClick = { showCreateEcoDialog = false }) { Text("戻る") } }
        )
    }
}
