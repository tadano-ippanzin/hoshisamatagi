package com.example.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

// 1. 深宇宙・天体観測 (Celestial Astrolabe)
val CelestialColorScheme: ColorScheme = darkColorScheme(
    primary = Color(0xFFF4C95D),
    onPrimary = Color(0xFF1E1702),
    primaryContainer = Color(0xFF3E300D),
    onPrimaryContainer = Color(0xFFFFE59D),
    secondary = Color(0xFF5EEAD4),
    onSecondary = Color(0xFF042622),
    secondaryContainer = Color(0xFF113C38),
    onSecondaryContainer = Color(0xFFB5F7EC),
    tertiary = Color(0xFFA78BFA),
    onTertiary = Color(0xFF1F1147),
    background = Color(0xFF090D1A),
    onBackground = Color(0xFFEAF0FF),
    surface = Color(0xFF10172A),
    onSurface = Color(0xFFEAF0FF),
    surfaceVariant = Color(0xFF1B243E),
    onSurfaceVariant = Color(0xFFB4C0DF),
    outline = Color(0xFF38466E),
    error = Color(0xFFFF6B7A),
    onError = Color(0xFF37060C)
)

// 2. 羊皮紙・古地図 (Parchment Cartography)
val ParchmentColorScheme: ColorScheme = lightColorScheme(
    primary = Color(0xFF9C4221),
    onPrimary = Color(0xFFFFF8F0),
    primaryContainer = Color(0xFFF3D5C0),
    onPrimaryContainer = Color(0xFF421706),
    secondary = Color(0xFF2B6CB0),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFD5E4F4),
    onSecondaryContainer = Color(0xFF0D2F54),
    tertiary = Color(0xFF2F855A),
    onTertiary = Color(0xFFFFFFFF),
    background = Color(0xFFF4EAD5),
    onBackground = Color(0xFF2D1E12),
    surface = Color(0xFFFAF2E1),
    onSurface = Color(0xFF2D1E12),
    surfaceVariant = Color(0xFFE9DABF),
    onSurfaceVariant = Color(0xFF5D4837),
    outline = Color(0xFFB59E7D),
    error = Color(0xFFB91C1C),
    onError = Color(0xFFFFFFFF)
)

// 3. ジオメトリック・モダン (Minimal Geometric)
val GeometricColorScheme: ColorScheme = lightColorScheme(
    primary = Color(0xFF2563EB),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFDBEAFE),
    onPrimaryContainer = Color(0xFF102A6B),
    secondary = Color(0xFFF97316),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFFFEDD5),
    onSecondaryContainer = Color(0xFF662903),
    tertiary = Color(0xFF0D9488),
    onTertiary = Color(0xFFFFFFFF),
    background = Color(0xFFF5F7FB),
    onBackground = Color(0xFF0F172A),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFE5EAF4),
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFCBD5E1),
    error = Color(0xFFDC2626),
    onError = Color(0xFFFFFFFF)
)

// 4. レトロドット箱庭 (Retro Pixel Diorama)
val RetroPixelColorScheme: ColorScheme = darkColorScheme(
    primary = Color(0xFF4ADE80),
    onPrimary = Color(0xFF062914),
    primaryContainer = Color(0xFF144225),
    onPrimaryContainer = Color(0xFFB8FAD0),
    secondary = Color(0xFFFBBF24),
    onSecondary = Color(0xFF2B1D00),
    secondaryContainer = Color(0xFF4B3607),
    onSecondaryContainer = Color(0xFFFDE68A),
    tertiary = Color(0xFF38BDF8),
    onTertiary = Color(0xFF052436),
    background = Color(0xFF141824),
    onBackground = Color(0xFFF1F5F9),
    surface = Color(0xFF1E2436),
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = Color(0xFF2A324B),
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = Color(0xFF4B5578),
    error = Color(0xFFF87171),
    onError = Color(0xFF3B0909)
)
