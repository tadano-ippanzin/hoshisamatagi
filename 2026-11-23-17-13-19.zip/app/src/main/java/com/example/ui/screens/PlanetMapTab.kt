package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddLocationAlt
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.BiomeType
import com.example.model.Nation
import com.example.model.Village
import com.example.model.WorldBundle
import com.example.model.WorldCodecs
import com.example.ui.theme.LocalVisualThemeMode
import com.example.ui.theme.VisualThemeMode

enum class MapToolMode(val label: String) {
    INSPECT("観測・村開く"),
    PAINT_BIOME("土地ペイント"),
    PAINT_NATION("国境ペイント"),
    PLACE_VILLAGE("村を配置")
}

@Composable
fun PlanetMapTab(
    bundle: WorldBundle,
    onPaintBiome: (Int, Int, BiomeType) -> Unit,
    onPaintNation: (Int, Int, String) -> Unit,
    onPlaceVillage: (Int, Int, String, String) -> Unit,
    onRegenerateTerrain: () -> Unit,
    onOpenVillage: (Village) -> Unit
) {
    val world = bundle.world
    val gridW = world.gridWidth.toInt().coerceIn(4, 24)
    val gridH = world.gridHeight.toInt().coerceIn(4, 24)
    val themeMode = LocalVisualThemeMode.current

    var toolMode by remember { mutableStateOf(MapToolMode.INSPECT) }
    var selectedBiome by remember { mutableStateOf(BiomeType.FOREST) }
    var selectedNationId by remember(bundle.nations) {
        mutableStateOf(bundle.nations.firstOrNull()?.id.orEmpty())
    }
    var inspectedTile by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var pendingVillageCoord by remember { mutableStateOf<Pair<Int, Int>?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Tool Mode Selector
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MapToolMode.entries.forEach { mode ->
                FilterChip(
                    selected = toolMode == mode,
                    onClick = { toolMode = mode },
                    leadingIcon = {
                        Icon(
                            imageVector = when (mode) {
                                MapToolMode.INSPECT -> Icons.Filled.TouchApp
                                MapToolMode.PAINT_BIOME -> Icons.Filled.Brush
                                MapToolMode.PAINT_NATION -> Icons.Filled.Flag
                                MapToolMode.PLACE_VILLAGE -> Icons.Filled.AddLocationAlt
                            },
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    label = { Text(mode.label) },
                    modifier = Modifier.testTag("map_tool_${mode.name}")
                )
            }
            OutlinedButton(onClick = onRegenerateTerrain) {
                Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("地形再生成")
            }
        }

        // Sub-palette based on active tool
        if (toolMode == MapToolMode.PAINT_BIOME) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                BiomeType.entries.forEach { biome ->
                    FilterChip(
                        selected = selectedBiome == biome,
                        onClick = { selectedBiome = biome },
                        leadingIcon = {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(Color(biome.defaultColor))
                            )
                        },
                        label = { Text(biome.label) }
                    )
                }
            }
        } else if (toolMode == MapToolMode.PAINT_NATION) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = selectedNationId.isBlank(),
                    onClick = { selectedNationId = "" },
                    label = { Text("無所属(消去)") }
                )
                bundle.nations.forEach { nation ->
                    FilterChip(
                        selected = selectedNationId == nation.id,
                        onClick = { selectedNationId = nation.id },
                        leadingIcon = {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(Color(nation.colorHex))
                            )
                        },
                        label = { Text(nation.name) }
                    )
                }
            }
        }

        // Interactive Planet Canvas Map
        val nationMap = remember(bundle.nations) { bundle.nations.associateBy { it.id } }
        val gridOutlineColor = MaterialTheme.colorScheme.outline.copy(
            alpha = when (themeMode) {
                VisualThemeMode.PARCHMENT_MAP -> 0.45f
                VisualThemeMode.RETRO_PIXEL -> 0.65f
                else -> 0.25f
            }
        )
        val markerBorder = MaterialTheme.colorScheme.onPrimary

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(gridW.toFloat() / gridH.toFloat())
                .clip(MaterialTheme.shapes.medium)
                .border(1.5.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.medium)
                .pointerInput(toolMode, selectedBiome, selectedNationId, bundle.villages) {
                    detectTapGestures { offset ->
                        val cellX = ((offset.x / size.width) * gridW).toInt().coerceIn(0, gridW - 1)
                        val cellY = ((offset.y / size.height) * gridH).toInt().coerceIn(0, gridH - 1)
                        when (toolMode) {
                            MapToolMode.INSPECT -> {
                                val vil = bundle.villages.firstOrNull {
                                    it.mapX.toInt() == cellX && it.mapY.toInt() == cellY
                                }
                                if (vil != null) {
                                    onOpenVillage(vil)
                                } else {
                                    inspectedTile = cellX to cellY
                                }
                            }
                            MapToolMode.PAINT_BIOME -> {
                                onPaintBiome(cellX, cellY, selectedBiome)
                                inspectedTile = cellX to cellY
                            }
                            MapToolMode.PAINT_NATION -> {
                                onPaintNation(cellX, cellY, selectedNationId)
                                inspectedTile = cellX to cellY
                            }
                            MapToolMode.PLACE_VILLAGE -> {
                                pendingVillageCoord = cellX to cellY
                            }
                        }
                    }
                }
                .testTag("planet_map_canvas")
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cellW = size.width / gridW
                val cellH = size.height / gridH

                for (y in 0 until gridH) {
                    for (x in 0 until gridW) {
                        val idx = y * gridW + x
                        val code = world.terrainTiles.getOrElse(idx) {
                            WorldCodecs.encodeTile(BiomeType.DEEP_OCEAN)
                        }
                        val biome = WorldCodecs.decodeBiome(code)
                        val elev = WorldCodecs.decodeElevation(code)
                        val baseColor = Color(biome.defaultColor)

                        val styledColor = when (themeMode) {
                            VisualThemeMode.PARCHMENT_MAP -> baseColor.copy(alpha = 0.72f)
                            VisualThemeMode.CELESTIAL_ASTROLABE -> {
                                val shade = 0.78f + (elev / 400f)
                                Color(
                                    red = (baseColor.red * shade).coerceIn(0f, 1f),
                                    green = (baseColor.green * shade).coerceIn(0f, 1f),
                                    blue = (baseColor.blue * shade).coerceIn(0f, 1f)
                                )
                            }
                            else -> baseColor
                        }

                        if (themeMode == VisualThemeMode.GEOMETRIC_MINIMAL) {
                            drawRoundRect(
                                color = styledColor,
                                topLeft = Offset(x * cellW + 1f, y * cellH + 1f),
                                size = Size(cellW - 2f, cellH - 2f),
                                cornerRadius = CornerRadius(6f, 6f)
                            )
                        } else {
                            drawRect(
                                color = styledColor,
                                topLeft = Offset(x * cellW, y * cellH),
                                size = Size(cellW + 0.6f, cellH + 0.6f)
                            )
                        }

                        // Nation border/tint overlay
                        val nId = world.nationGrid.getOrElse(idx) { "" }
                        val nation = nationMap[nId]
                        if (nation != null) {
                            val nColor = Color(nation.colorHex)
                            drawRect(
                                color = nColor.copy(alpha = 0.28f),
                                topLeft = Offset(x * cellW, y * cellH),
                                size = Size(cellW, cellH)
                            )
                            drawRect(
                                color = nColor.copy(alpha = 0.9f),
                                topLeft = Offset(x * cellW + 1.5f, y * cellH + 1.5f),
                                size = Size(cellW - 3f, cellH - 3f),
                                style = Stroke(width = 2.5f)
                            )
                        }

                        // Gridline
                        drawRect(
                            color = gridOutlineColor,
                            topLeft = Offset(x * cellW, y * cellH),
                            size = Size(cellW, cellH),
                            style = Stroke(width = if (themeMode == VisualThemeMode.RETRO_PIXEL) 1.5f else 0.8f)
                        )
                    }
                }

                // Highlight inspected tile
                inspectedTile?.let { (ix, iy) ->
                    drawRect(
                        color = Color.White,
                        topLeft = Offset(ix * cellW + 2f, iy * cellH + 2f),
                        size = Size(cellW - 4f, cellH - 4f),
                        style = Stroke(width = 3f)
                    )
                }

                // Village pins
                bundle.villages.forEach { vil ->
                    val vx = (vil.mapX.toFloat() + 0.5f) * cellW
                    val vy = (vil.mapY.toFloat() + 0.5f) * cellH
                    val radius = (minOf(cellW, cellH) * 0.34f).coerceAtLeast(7f)
                    val pinColor = nationMap[vil.nationId]?.let { Color(it.colorHex) } ?: Color(0xFFF4C95D)
                    drawCircle(color = Color.Black.copy(alpha = 0.55f), radius = radius + 2.5f, center = Offset(vx, vy))
                    drawCircle(color = pinColor, radius = radius, center = Offset(vx, vy))
                    drawCircle(color = markerBorder, radius = radius, center = Offset(vx, vy), style = Stroke(width = 2f))
                }
            }
        }

        // Inspected tile readout & quick village list
        inspectedTile?.let { (tx, ty) ->
            val idx = ty * gridW + tx
            val code = world.terrainTiles.getOrElse(idx) { 352L }
            val biome = WorldCodecs.decodeBiome(code)
            val elev = WorldCodecs.decodeElevation(code)
            val nId = world.nationGrid.getOrElse(idx) { "" }
            val nation = nationMap[nId]
            val villageHere = bundle.villages.firstOrNull { it.mapX.toInt() == tx && it.mapY.toInt() == ty }

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "座標 (${tx}, ${ty}) — ${biome.label}（標高 ${elev}）",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "領土: ${nation?.name ?: "未開地"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (villageHere != null) {
                        Button(onClick = { onOpenVillage(villageHere) }) {
                            Text("区画を開く")
                        }
                    } else {
                        OutlinedButton(onClick = { pendingVillageCoord = tx to ty }) {
                            Text("村を建てる")
                        }
                    }
                }
            }
        }

        // Quick tap cards for existing villages on the planet
        if (bundle.villages.isNotEmpty()) {
            Text(
                text = "惑星上の村・都市（タップして区画グリッドへズーム）",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                bundle.villages.forEach { vil ->
                    val nName = nationMap[vil.nationId]?.name ?: "独立"
                    Surface(
                        onClick = { onOpenVillage(vil) },
                        shape = MaterialTheme.shapes.medium,
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.testTag("map_village_chip_${vil.id}")
                    ) {
                        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                            Text(vil.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Text(
                                "$nName ・ 人口 ${vil.population}人",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }

    pendingVillageCoord?.let { (vx, vy) ->
        var vName by remember { mutableStateOf("") }
        var vNation by remember { mutableStateOf(selectedNationId) }
        AlertDialog(
            onDismissRequest = { pendingVillageCoord = null },
            title = { Text("座標 ($vx, $vy) に村を開拓") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = vName,
                        onValueChange = { vName = it },
                        label = { Text("村の名前（空欄で自動命名）") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (bundle.nations.isNotEmpty()) {
                        Text("所属国家", style = MaterialTheme.typography.labelMedium)
                        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(selected = vNation.isBlank(), onClick = { vNation = "" }, label = { Text("独立") })
                            bundle.nations.forEach { n ->
                                FilterChip(selected = vNation == n.id, onClick = { vNation = n.id }, label = { Text(n.name) })
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    onPlaceVillage(vx, vy, vNation, vName)
                    pendingVillageCoord = null
                }) { Text("開拓する") }
            },
            dismissButton = {
                TextButton(onClick = { pendingVillageCoord = null }) { Text("戻る") }
            }
        )
    }
}
