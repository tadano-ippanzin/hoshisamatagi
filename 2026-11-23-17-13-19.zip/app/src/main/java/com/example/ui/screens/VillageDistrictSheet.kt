package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Upgrade
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.DistrictCell
import com.example.model.DistrictType
import com.example.model.GenerationMode
import com.example.model.Nation
import com.example.model.Person
import com.example.model.Village
import com.example.model.WorldCodecs

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun VillageDistrictSheet(
    village: Village,
    nations: List<Nation>,
    peopleInVillage: List<Person>,
    generationMode: GenerationMode,
    isGenerating: Boolean,
    onDismiss: () -> Unit,
    onSaveVillage: (Village) -> Unit,
    onUpdateDistrictCell: (Int, Int, DistrictType?, String) -> Unit,
    onCreatePerson: (DistrictType) -> Unit,
    onDeletePerson: (String) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val cells = remember(village.districtCells) {
        village.districtCells.mapNotNull { WorldCodecs.decodeDistrictCell(it) }
    }
    var selectedCoord by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var editingMeta by remember { mutableStateOf(false) }

    val nationName = nations.firstOrNull { it.id == village.nationId }?.name ?: "独立集落"

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Filled.LocationCity,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Column {
                        Text(village.name, style = MaterialTheme.typography.headlineSmall)
                        Text(
                            text = "$nationName ・ 座標(${village.mapX},${village.mapY}) ・ 人口 ${village.population}人 ・ 繁栄度 ${village.prosperity}%",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                TextButton(onClick = { editingMeta = true }) {
                    Text("村設定")
                }
                IconButton(onClick = onDismiss, modifier = Modifier.minimumInteractiveComponentSize()) {
                    Icon(Icons.Filled.Close, contentDescription = "閉じる")
                }
            }

            if (village.specialty.isNotBlank()) {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = MaterialTheme.shapes.small
                ) {
                    Text(
                        text = "特産・特色: ${village.specialty}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            Text(
                text = "区画グリッド (6×6) — マスをタップして区画を建設・発展",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(MaterialTheme.shapes.medium)
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                for (y in 0 until 6) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        for (x in 0 until 6) {
                            val cell = cells.firstOrNull { it.x == x && it.y == y }
                            val bgColor = cell?.let { Color(it.type.colorHex).copy(alpha = 0.25f) }
                                ?: MaterialTheme.colorScheme.surface
                            val borderColor = cell?.let { Color(it.type.colorHex) }
                                ?: MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .clip(MaterialTheme.shapes.extraSmall)
                                    .background(bgColor)
                                    .border(1.2.dp, borderColor, MaterialTheme.shapes.extraSmall)
                                    .clickable { selectedCoord = x to y }
                                    .testTag("district_cell_${x}_$y"),
                                contentAlignment = Alignment.Center
                            ) {
                                if (cell != null) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.padding(2.dp)
                                    ) {
                                        Text(
                                            text = cell.type.label.take(3),
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Clip,
                                            textAlign = TextAlign.Center
                                        )
                                        Text(
                                            text = "Lv${cell.level}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                } else {
                                    Text(
                                        text = "+",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            HorizontalDivider()

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "村の住民 (${peopleInVillage.size}名)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Button(
                    onClick = {
                        val activeType = cells.randomOrNull()?.type ?: DistrictType.RESIDENTIAL
                        onCreatePerson(activeType)
                    },
                    enabled = !isGenerating,
                    modifier = Modifier.testTag("spawn_villager_button")
                ) {
                    Icon(Icons.Filled.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("${generationMode.shortLabel}で住民を追加")
                }
            }

            if (peopleInVillage.isEmpty()) {
                Text(
                    text = "まだ記録された住民がいません。上のボタンで住民を誕生させましょう。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    peopleInVillage.forEach { person ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${person.name}（${person.age}歳・${person.role}）",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "${DistrictType.fromKey(person.districtType).label} ・ ${person.traits}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    if (person.biography.isNotBlank()) {
                                        Text(
                                            text = person.biography,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                IconButton(
                                    onClick = { onDeletePerson(person.id) },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(Icons.Filled.Delete, contentDescription = "${person.name}を削除")
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    selectedCoord?.let { (gx, gy) ->
        val existingCell = cells.firstOrNull { it.x == gx && it.y == gy }
        DistrictEditorDialog(
            gx = gx,
            gy = gy,
            existingCell = existingCell,
            onDismiss = { selectedCoord = null },
            onBuildOrUpgrade = { type, label ->
                onUpdateDistrictCell(gx, gy, type, label)
                selectedCoord = null
            },
            onDemolish = {
                onUpdateDistrictCell(gx, gy, null, "")
                selectedCoord = null
            }
        )
    }

    if (editingMeta) {
        var vName by remember { mutableStateOf(village.name) }
        var vSpec by remember { mutableStateOf(village.specialty) }
        var vNationId by remember { mutableStateOf(village.nationId) }
        AlertDialog(
            onDismissRequest = { editingMeta = false },
            title = { Text("村・集落の設定") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = vName,
                        onValueChange = { vName = it },
                        label = { Text("村の名前") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = vSpec,
                        onValueChange = { vSpec = it },
                        label = { Text("特産品・役割") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("所属国家", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = vNationId.isBlank(),
                            onClick = { vNationId = "" },
                            label = { Text("独立") }
                        )
                        nations.forEach { n ->
                            FilterChip(
                                selected = vNationId == n.id,
                                onClick = { vNationId = n.id },
                                label = { Text(n.name) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    onSaveVillage(village.copy(name = vName, specialty = vSpec, nationId = vNationId))
                    editingMeta = false
                }) { Text("保存") }
            },
            dismissButton = {
                TextButton(onClick = { editingMeta = false }) { Text("閉じる") }
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DistrictEditorDialog(
    gx: Int,
    gy: Int,
    existingCell: DistrictCell?,
    onDismiss: () -> Unit,
    onBuildOrUpgrade: (DistrictType, String) -> Unit,
    onDemolish: () -> Unit
) {
    var chosenType by remember { mutableStateOf(existingCell?.type ?: DistrictType.RESIDENTIAL) }
    var customLabel by remember { mutableStateOf(existingCell?.label ?: chosenType.label) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (existingCell == null) "区画を建設 (${gx + 1},${gy + 1})"
                else "${existingCell.label} Lv${existingCell.level} の管理"
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("区画の種類を選択", style = MaterialTheme.typography.labelMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    DistrictType.entries.forEach { dt ->
                        FilterChip(
                            selected = chosenType == dt,
                            onClick = {
                                chosenType = dt
                                customLabel = dt.label
                            },
                            label = { Text(dt.label) }
                        )
                    }
                }
                OutlinedTextField(
                    value = customLabel,
                    onValueChange = { customLabel = it },
                    label = { Text("区画の名称") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onBuildOrUpgrade(chosenType, customLabel) },
                modifier = Modifier.testTag("confirm_district_button")
            ) {
                Icon(
                    imageVector = if (existingCell != null && existingCell.type == chosenType) Icons.Filled.Upgrade else Icons.Filled.Add,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(4.dp))
                Text(if (existingCell != null && existingCell.type == chosenType) "強化 (LvUP)" else "建設")
            }
        },
        dismissButton = {
            Row {
                if (existingCell != null) {
                    OutlinedButton(onClick = onDemolish) {
                        Text("解体")
                    }
                    Spacer(Modifier.width(6.dp))
                }
                TextButton(onClick = onDismiss) { Text("閉じる") }
            }
        }
    )
}
