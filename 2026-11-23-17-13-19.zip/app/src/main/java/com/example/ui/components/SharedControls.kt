package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.engine.ProceduralGenerator
import com.example.model.BiomeType
import com.example.model.GenerationMode
import com.example.model.GlyphDefinition
import com.example.model.GlyphPoint
import com.example.model.World
import com.example.model.WorldCodecs
import com.example.ui.theme.VisualThemeMode
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun GenerationModeSelector(
    mode: GenerationMode,
    onModeChange: (GenerationMode) -> Unit,
    modifier: Modifier = Modifier
) {
    SingleChoiceSegmentedButtonRow(modifier = modifier.testTag("generation_mode_selector")) {
        GenerationMode.entries.forEachIndexed { index, item ->
            SegmentedButton(
                selected = mode == item,
                onClick = { onModeChange(item) },
                shape = SegmentedButtonDefaults.itemShape(index, GenerationMode.entries.size),
                icon = {
                    Icon(
                        imageVector = if (item == GenerationMode.AI) Icons.Filled.AutoAwesome else Icons.Filled.Tune,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                },
                label = {
                    Text(
                        text = item.shortLabel,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            )
        }
    }
}

@Composable
fun ThemePickerButton(
    currentTheme: VisualThemeMode,
    onSelectTheme: (VisualThemeMode) -> Unit,
    modifier: Modifier = Modifier
) {
    var openDialog by remember { mutableStateOf(false) }

    IconButton(
        onClick = { openDialog = true },
        modifier = modifier
            .minimumInteractiveComponentSize()
            .testTag("theme_picker_button")
    ) {
        Icon(
            imageVector = Icons.Filled.Palette,
            contentDescription = "ビジュアルテーマを変更",
            tint = MaterialTheme.colorScheme.primary
        )
    }

    if (openDialog) {
        AlertDialog(
            onDismissRequest = { openDialog = false },
            title = { Text("ビジュアルテーマを選択") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    VisualThemeMode.entries.forEach { option ->
                        val selected = option == currentTheme
                        Card(
                            onClick = {
                                onSelectTheme(option)
                                openDialog = false
                            },
                            colors = CardDefaults.cardColors(
                                containerColor = if (selected) {
                                    MaterialTheme.colorScheme.primaryContainer
                                } else {
                                    MaterialTheme.colorScheme.surfaceVariant
                                }
                            ),
                            border = if (selected) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("theme_option_${option.name}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = option.displayName,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = option.subtitle,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (selected) {
                                    Icon(
                                        imageVector = Icons.Filled.Check,
                                        contentDescription = "選択中",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { openDialog = false }) {
                    Text("閉じる")
                }
            }
        )
    }
}

@Composable
fun GlyphCanvasView(
    glyph: GlyphDefinition,
    strokeColor: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val pad = size.minDimension * 0.1f
        val drawW = size.width - pad * 2f
        val drawH = size.height - pad * 2f
        val strokeWidth = (size.minDimension * 0.09f).coerceIn(2f, 8f)

        glyph.strokes.forEach { pts ->
            if (pts.size >= 2) {
                val path = Path().apply {
                    moveTo(pad + pts[0].x * drawW, pad + pts[0].y * drawH)
                    for (i in 1 until pts.size) {
                        lineTo(pad + pts[i].x * drawW, pad + pts[i].y * drawH)
                    }
                }
                drawPath(
                    path = path,
                    color = strokeColor,
                    style = Stroke(
                        width = strokeWidth,
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )
            } else if (pts.size == 1) {
                drawCircle(
                    color = strokeColor,
                    radius = strokeWidth * 0.65f,
                    center = Offset(pad + pts[0].x * drawW, pad + pts[0].y * drawH)
                )
            }
        }
    }
}

@Composable
fun GlyphEditorDialog(
    initialGlyph: GlyphDefinition,
    onDismiss: () -> Unit,
    onSave: (GlyphDefinition) -> Unit
) {
    val strokes = remember(initialGlyph) {
        mutableStateListOf<List<GlyphPoint>>().apply {
            addAll(initialGlyph.strokes)
        }
    }
    var activeStroke by remember { mutableStateOf<List<GlyphPoint>>(emptyList()) }
    val primaryColor = MaterialTheme.colorScheme.primary
    val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("文字グリフ編集：「${initialGlyph.symbolKey}」")
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "枠内を指でなぞって独自文字の筆画を描けます。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                        .clip(MaterialTheme.shapes.medium)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(1.5.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.medium)
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { offset ->
                                    val nx = (offset.x / size.width).coerceIn(0f, 1f)
                                    val ny = (offset.y / size.height).coerceIn(0f, 1f)
                                    activeStroke = listOf(GlyphPoint(nx, ny))
                                },
                                onDrag = { change, _ ->
                                    change.consume()
                                    val nx = (change.position.x / size.width).coerceIn(0f, 1f)
                                    val ny = (change.position.y / size.height).coerceIn(0f, 1f)
                                    val last = activeStroke.lastOrNull()
                                    if (last == null || kotlin.math.hypot(nx - last.x, ny - last.y) > 0.03f) {
                                        activeStroke = (activeStroke + GlyphPoint(nx, ny)).take(28)
                                    }
                                },
                                onDragEnd = {
                                    if (activeStroke.isNotEmpty()) {
                                        strokes.add(activeStroke)
                                    }
                                    activeStroke = emptyList()
                                },
                                onDragCancel = {
                                    activeStroke = emptyList()
                                }
                            )
                        }
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        // Guide crosshair
                        drawLine(
                            color = gridColor,
                            start = Offset(size.width / 2f, 0f),
                            end = Offset(size.width / 2f, size.height),
                            strokeWidth = 1.5f
                        )
                        drawLine(
                            color = gridColor,
                            start = Offset(0f, size.height / 2f),
                            end = Offset(size.width, size.height / 2f),
                            strokeWidth = 1.5f
                        )
                        val allStrokes = strokes + listOfNotNull(activeStroke.takeIf { it.isNotEmpty() })
                        allStrokes.forEach { pts ->
                            if (pts.size >= 2) {
                                val path = Path().apply {
                                    moveTo(pts[0].x * size.width, pts[0].y * size.height)
                                    for (i in 1 until pts.size) {
                                        lineTo(pts[i].x * size.width, pts[i].y * size.height)
                                    }
                                }
                                drawPath(
                                    path = path,
                                    color = primaryColor,
                                    style = Stroke(width = 10f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                                )
                            } else if (pts.size == 1) {
                                drawCircle(
                                    color = primaryColor,
                                    radius = 6f,
                                    center = Offset(pts[0].x * size.width, pts[0].y * size.height)
                                )
                            }
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { if (strokes.isNotEmpty()) strokes.removeAt(strokes.lastIndex) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("戻す")
                    }
                    OutlinedButton(
                        onClick = {
                            strokes.clear()
                            strokes.addAll(ProceduralGenerator.generateProceduralGlyph(initialGlyph.symbolKey).strokes)
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("自動")
                    }
                    OutlinedButton(
                        onClick = { strokes.clear() },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Filled.Clear, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("消去")
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(GlyphDefinition(initialGlyph.symbolKey, strokes.toList())) },
                modifier = Modifier.testTag("save_glyph_button")
            ) {
                Text("文字を保存")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("キャンセル")
            }
        }
    )
}

@Composable
fun SacredEmblemView(
    sides: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    val safeSides = sides.coerceIn(3, 12)
    Canvas(modifier = modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val r = size.minDimension * 0.42f
        val outerPath = Path()
        val innerPath = Path()
        for (i in 0 until safeSides) {
            val angle = -PI / 2.0 + (2.0 * PI * i / safeSides)
            val px = cx + (r * cos(angle)).toFloat()
            val py = cy + (r * sin(angle)).toFloat()
            val ix = cx + (r * 0.55f * cos(angle + PI / safeSides)).toFloat()
            val iy = cy + (r * 0.55f * sin(angle + PI / safeSides)).toFloat()
            if (i == 0) {
                outerPath.moveTo(px, py)
                innerPath.moveTo(ix, iy)
            } else {
                outerPath.lineTo(px, py)
                innerPath.lineTo(ix, iy)
            }
        }
        outerPath.close()
        innerPath.close()
        drawCircle(color = color.copy(alpha = 0.14f), radius = r * 1.05f, center = Offset(cx, cy))
        drawPath(outerPath, color = color, style = Stroke(width = 3.5f, join = StrokeJoin.Round))
        drawPath(innerPath, color = color.copy(alpha = 0.8f), style = Stroke(width = 2.2f, join = StrokeJoin.Round))
        drawCircle(color = color, radius = r * 0.16f, center = Offset(cx, cy))
    }
}

@Composable
fun MiniPlanetPreview(
    world: World,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val w = world.gridWidth.toInt().coerceAtLeast(1)
        val h = world.gridHeight.toInt().coerceAtLeast(1)
        val cellW = size.width / w
        val cellH = size.height / h
        for (y in 0 until h) {
            for (x in 0 until w) {
                val idx = y * w + x
                val code = world.terrainTiles.getOrElse(idx) { WorldCodecs.encodeTile(BiomeType.DEEP_OCEAN) }
                val biome = WorldCodecs.decodeBiome(code)
                drawRect(
                    color = Color(biome.defaultColor),
                    topLeft = Offset(x * cellW, y * cellH),
                    size = Size(cellW + 0.5f, cellH + 0.5f)
                )
            }
        }
    }
}
