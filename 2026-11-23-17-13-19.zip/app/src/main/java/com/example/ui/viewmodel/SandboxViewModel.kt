package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.WorldRepository
import com.example.engine.AiWorldGenerator
import com.example.engine.ProceduralGenerator
import com.example.model.BiomeType
import com.example.model.Chronicle
import com.example.model.Culture
import com.example.model.DistrictCell
import com.example.model.DistrictType
import com.example.model.Ecosystem
import com.example.model.GenerationMode
import com.example.model.GlyphDefinition
import com.example.model.Language
import com.example.model.Nation
import com.example.model.Person
import com.example.model.Religion
import com.example.model.Species
import com.example.model.UiState
import com.example.model.Village
import com.example.model.World
import com.example.model.WorldBundle
import com.example.model.WorldCodecs
import com.example.model.WorldElement
import com.example.ui.theme.VisualThemeMode
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SandboxViewModel(
    private val repository: WorldRepository,
    private val aiGenerator: AiWorldGenerator,
    private val currentUserId: String,
    private val worldId: String
) : ViewModel() {

    private val coreBundleFlow: Flow<WorldBundle> = combine(
        repository.observeWorld(currentUserId, worldId),
        repository.observeElements(currentUserId, worldId),
        repository.observeEcosystems(currentUserId, worldId),
        repository.observeSpecies(currentUserId, worldId),
        repository.observeLanguages(currentUserId, worldId)
    ) { world, elements, ecosystems, species, languages ->
        WorldBundle(
            world = world ?: World(id = worldId, userId = currentUserId, name = "読み込み中"),
            elements = elements.sortedBy { it.atomicNumber },
            ecosystems = ecosystems,
            species = species,
            languages = languages
        )
    }

    private val civBundleFlow: Flow<WorldBundle> = combine(
        repository.observeCultures(currentUserId, worldId),
        repository.observeReligions(currentUserId, worldId),
        repository.observeNations(currentUserId, worldId),
        repository.observeVillages(currentUserId, worldId),
        repository.observePeople(currentUserId, worldId)
    ) { cultures, religions, nations, villages, people ->
        WorldBundle(
            cultures = cultures,
            religions = religions,
            nations = nations,
            villages = villages,
            people = people
        )
    }

    val bundleState: StateFlow<UiState<WorldBundle>> = combine(
        coreBundleFlow,
        civBundleFlow,
        repository.observeChronicles(currentUserId, worldId)
    ) { core, civ, chronicles ->
        UiState.Success(
            core.copy(
                cultures = civ.cultures,
                religions = civ.religions,
                nations = civ.nations,
                villages = civ.villages,
                people = civ.people,
                chronicles = chronicles.sortedByDescending { it.year }
            )
        ) as UiState<WorldBundle>
    }.catch { error ->
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        Log.w(TAG, "Error observing world bundle", rootError)
        emit(UiState.Error(rootError.message ?: "惑星データの同期に失敗しました。"))
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = UiState.Loading
    )

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    private val _clockSpeed = MutableStateFlow(0) // 0=Paused, 1=1x, 3=3x
    val clockSpeed: StateFlow<Int> = _clockSpeed.asStateFlow()

    private var clockJob: Job? = null

    fun clearFeedback() {
        _feedbackMessage.value = null
    }

    private fun currentBundle(): WorldBundle? =
        (bundleState.value as? UiState.Success)?.data

    fun setClockSpeed(speed: Int) {
        _clockSpeed.value = speed
        clockJob?.cancel()
        if (speed > 0) {
            clockJob = viewModelScope.launch {
                while (true) {
                    delay(if (speed >= 3) 2500L else 5500L)
                    advanceTime(if (speed >= 3) 10L else 2L, useAiChronicle = false)
                }
            }
        }
    }

    fun advanceTime(years: Long, useAiChronicle: Boolean) {
        val bundle = currentBundle() ?: return
        viewModelScope.launch {
            val sim = ProceduralGenerator.simulateYears(bundle.world, bundle, years)
            repository.updateWorldGridAndMeta(
                userId = currentUserId,
                worldId = worldId,
                currentYear = sim.newYear
            ).onFailure {
                _feedbackMessage.value = it.localizedMessage ?: "年表進行に失敗しました。"
            }
            sim.updatedVillages.take(5).forEach { v ->
                repository.saveVillage(currentUserId, worldId, v)
            }
            if (useAiChronicle) {
                _isGenerating.value = true
                val aiRes = aiGenerator.generateChronicleAi(
                    bundle.world.copy(currentYear = sim.newYear),
                    bundle
                )
                _isGenerating.value = false
                aiRes.onSuccess { chr ->
                    repository.saveChronicle(currentUserId, worldId, chr)
                }.onFailure { err ->
                    _feedbackMessage.value = "AI年表生成に失敗: ${err.localizedMessage}"
                }
            } else if (sim.generatedChronicle != null) {
                repository.saveChronicle(currentUserId, worldId, sim.generatedChronicle)
            }
        }
    }

    fun updateWorldTheme(themeMode: VisualThemeMode) {
        viewModelScope.launch {
            repository.updateWorldGridAndMeta(
                userId = currentUserId,
                worldId = worldId,
                visualTheme = themeMode
            )
        }
    }

    fun updateWorldMetadata(name: String, starType: String, eraName: String, description: String) {
        viewModelScope.launch {
            repository.updateWorldGridAndMeta(
                userId = currentUserId,
                worldId = worldId,
                name = name,
                starType = starType,
                eraName = eraName,
                description = description
            ).onSuccess {
                _feedbackMessage.value = "星の基本設定を更新しました。"
            }.onFailure {
                _feedbackMessage.value = it.localizedMessage ?: "更新に失敗しました。"
            }
        }
    }

    fun paintTerrainTile(x: Int, y: Int, biome: BiomeType) {
        val world = currentBundle()?.world ?: return
        val w = world.gridWidth.toInt()
        val h = world.gridHeight.toInt()
        if (x !in 0 until w || y !in 0 until h) return
        val idx = y * w + x
        val updated = world.terrainTiles.toMutableList()
        while (updated.size < w * h) updated.add(WorldCodecs.encodeTile(BiomeType.PLAINS))
        updated[idx] = WorldCodecs.encodeTile(biome)
        viewModelScope.launch {
            repository.updateWorldGridAndMeta(currentUserId, worldId, terrainTiles = updated)
        }
    }

    fun regenerateTerrain() {
        val world = currentBundle()?.world ?: return
        val w = world.gridWidth.toInt()
        val h = world.gridHeight.toInt()
        val fresh = ProceduralGenerator.generatePlanetTerrain(w, h, System.currentTimeMillis())
        viewModelScope.launch {
            repository.updateWorldGridAndMeta(currentUserId, worldId, terrainTiles = fresh)
                .onSuccess { _feedbackMessage.value = "大陸と海を再生成しました。" }
        }
    }

    fun paintNationTile(x: Int, y: Int, nationId: String) {
        val world = currentBundle()?.world ?: return
        val w = world.gridWidth.toInt()
        val h = world.gridHeight.toInt()
        if (x !in 0 until w || y !in 0 until h) return
        val idx = y * w + x
        val updated = world.nationGrid.toMutableList()
        while (updated.size < w * h) updated.add("")
        updated[idx] = nationId
        viewModelScope.launch {
            repository.updateWorldGridAndMeta(currentUserId, worldId, nationGrid = updated)
        }
    }

    // --- Elements ---
    fun createOrGenerateElement(mode: GenerationMode, hint: String = "") {
        val bundle = currentBundle() ?: return
        viewModelScope.launch {
            val element = if (mode == GenerationMode.AI) {
                _isGenerating.value = true
                val res = aiGenerator.generateElementAi(bundle.world, hint)
                _isGenerating.value = false
                res.getOrElse { err ->
                    _feedbackMessage.value = "AI創世エラー: ${err.localizedMessage}"
                    return@launch
                }
            } else {
                ProceduralGenerator.generateElement(bundle.elements.size + 1, customName = hint.ifBlank { null })
            }
            repository.saveElement(currentUserId, worldId, element)
                .onSuccess { _feedbackMessage.value = "元素「${element.name}」を創造しました。" }
                .onFailure { _feedbackMessage.value = it.localizedMessage }
        }
    }

    fun saveElement(element: WorldElement) {
        viewModelScope.launch {
            repository.saveElement(currentUserId, worldId, element)
                .onFailure { _feedbackMessage.value = it.localizedMessage }
        }
    }

    fun synthesizeElements(a: WorldElement, b: WorldElement) {
        val compound = ProceduralGenerator.synthesizeCompound(a, b)
        viewModelScope.launch {
            repository.saveElement(currentUserId, worldId, compound)
                .onSuccess { _feedbackMessage.value = "化合物「${compound.name}」を合成しました。" }
                .onFailure { _feedbackMessage.value = it.localizedMessage }
        }
    }

    // --- Ecosystems & Species ---
    fun createEcosystemAndSpecies(mode: GenerationMode, biome: String) {
        val bundle = currentBundle() ?: return
        viewModelScope.launch {
            if (mode == GenerationMode.AI) {
                _isGenerating.value = true
                val res = aiGenerator.generateEcosystemAndSpeciesAi(bundle.world, bundle, biome)
                _isGenerating.value = false
                val pair = res.getOrElse { err ->
                    _feedbackMessage.value = "AI創世エラー: ${err.localizedMessage}"
                    return@launch
                }
                val ecoId = repository.saveEcosystem(currentUserId, worldId, pair.first).getOrNull().orEmpty()
                if (ecoId.isNotBlank()) {
                    repository.saveSpecies(currentUserId, worldId, pair.second.copy(ecosystemId = ecoId))
                }
                _feedbackMessage.value = "生態系「${pair.first.name}」と固有種を創造しました。"
            } else {
                val eco = ProceduralGenerator.generateEcosystem(
                    biome = biome,
                    keyResource = bundle.elements.firstOrNull()?.name ?: "星輝鉄"
                )
                val ecoId = repository.saveEcosystem(currentUserId, worldId, eco).getOrNull().orEmpty()
                val sp = ProceduralGenerator.generateSpecies(ecoId)
                repository.saveSpecies(currentUserId, worldId, sp)
                _feedbackMessage.value = "生態系「${eco.name}」を創造しました。"
            }
        }
    }

    fun saveEcosystem(ecosystem: Ecosystem) {
        viewModelScope.launch {
            repository.saveEcosystem(currentUserId, worldId, ecosystem)
                .onFailure { _feedbackMessage.value = it.localizedMessage }
        }
    }

    fun createSpecies(ecosystemId: String, role: String) {
        val sp = ProceduralGenerator.generateSpecies(ecosystemId, trophicRole = role)
        viewModelScope.launch {
            repository.saveSpecies(currentUserId, worldId, sp)
                .onSuccess { _feedbackMessage.value = "生物「${sp.name}」を追加しました。" }
                .onFailure { _feedbackMessage.value = it.localizedMessage }
        }
    }

    fun saveSpecies(species: Species) {
        viewModelScope.launch {
            repository.saveSpecies(currentUserId, worldId, species)
                .onFailure { _feedbackMessage.value = it.localizedMessage }
        }
    }

    // --- Languages & Scripts ---
    fun createLanguage(mode: GenerationMode, hint: String = "") {
        val bundle = currentBundle() ?: return
        viewModelScope.launch {
            val lang = if (mode == GenerationMode.AI) {
                _isGenerating.value = true
                val res = aiGenerator.generateLanguageAi(bundle.world, hint)
                _isGenerating.value = false
                res.getOrElse { err ->
                    _feedbackMessage.value = "AI創世エラー: ${err.localizedMessage}"
                    return@launch
                }
            } else {
                ProceduralGenerator.generateLanguageAndScript(customName = hint.ifBlank { null })
            }
            repository.saveLanguage(currentUserId, worldId, lang)
                .onSuccess { _feedbackMessage.value = "言語「${lang.name}」と「${lang.scriptName}」を創造しました。" }
                .onFailure { _feedbackMessage.value = it.localizedMessage }
        }
    }

    fun saveLanguage(language: Language) {
        viewModelScope.launch {
            repository.saveLanguage(currentUserId, worldId, language)
                .onFailure { _feedbackMessage.value = it.localizedMessage }
        }
    }

    fun updateLanguageGlyph(language: Language, glyph: GlyphDefinition) {
        val encoded = WorldCodecs.encodeGlyph(glyph)
        val existing = language.glyphStrokes.mapNotNull { WorldCodecs.decodeGlyph(it) }.toMutableList()
        val idx = existing.indexOfFirst { it.symbolKey == glyph.symbolKey }
        if (idx >= 0) existing[idx] = glyph else existing.add(glyph)
        val updated = language.copy(glyphStrokes = existing.take(48).map { WorldCodecs.encodeGlyph(it) })
        saveLanguage(updated)
    }

    fun addWordToLanguage(language: Language, customWord: String, meaning: String) {
        val vList = language.vowels.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        val cList = language.consonants.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        val word = customWord.trim().ifBlank {
            ProceduralGenerator.coinWord(vList, cList, language.syllablePattern, 2)
        }
        val entry = WorldCodecs.encodeLexiconEntry(word, meaning.ifBlank { "星" })
        val updatedList = (language.lexiconEntries + entry).take(80)
        saveLanguage(language.copy(lexiconEntries = updatedList))
    }

    // --- Cultures & Religions ---
    fun createCulture(mode: GenerationMode, hint: String = "") {
        val bundle = currentBundle() ?: return
        val lang = bundle.languages.firstOrNull()
        viewModelScope.launch {
            val culture = if (mode == GenerationMode.AI) {
                _isGenerating.value = true
                val res = aiGenerator.generateCultureAi(bundle.world, lang, hint)
                _isGenerating.value = false
                res.getOrElse { err ->
                    _feedbackMessage.value = "AI創世エラー: ${err.localizedMessage}"
                    return@launch
                }
            } else {
                ProceduralGenerator.generateCulture(customName = hint.ifBlank { null }, languageId = lang?.id.orEmpty())
            }
            repository.saveCulture(currentUserId, worldId, culture)
                .onSuccess { _feedbackMessage.value = "文化「${culture.name}」を創造しました。" }
                .onFailure { _feedbackMessage.value = it.localizedMessage }
        }
    }

    fun saveCulture(culture: Culture) {
        viewModelScope.launch {
            repository.saveCulture(currentUserId, worldId, culture)
                .onFailure { _feedbackMessage.value = it.localizedMessage }
        }
    }

    fun createReligion(mode: GenerationMode, hint: String = "") {
        val bundle = currentBundle() ?: return
        viewModelScope.launch {
            val rel = if (mode == GenerationMode.AI) {
                _isGenerating.value = true
                val res = aiGenerator.generateReligionAi(bundle.world, bundle, hint)
                _isGenerating.value = false
                res.getOrElse { err ->
                    _feedbackMessage.value = "AI創世エラー: ${err.localizedMessage}"
                    return@launch
                }
            } else {
                ProceduralGenerator.generateReligion(
                    customName = hint.ifBlank { null },
                    elementHint = bundle.elements.firstOrNull()?.name ?: "星輝鉄"
                )
            }
            repository.saveReligion(currentUserId, worldId, rel)
                .onSuccess { _feedbackMessage.value = "宗教「${rel.name}」を創設しました。" }
                .onFailure { _feedbackMessage.value = it.localizedMessage }
        }
    }

    fun saveReligion(religion: Religion) {
        viewModelScope.launch {
            repository.saveReligion(currentUserId, worldId, religion)
                .onFailure { _feedbackMessage.value = it.localizedMessage }
        }
    }

    // --- Nations, Villages, Districts & People ---
    fun createNation(mode: GenerationMode, hint: String = "") {
        val bundle = currentBundle() ?: return
        viewModelScope.launch {
            val nation = if (mode == GenerationMode.AI) {
                _isGenerating.value = true
                val res = aiGenerator.generateNationAi(bundle.world, bundle, hint)
                _isGenerating.value = false
                res.getOrElse { err ->
                    _feedbackMessage.value = "AI創世エラー: ${err.localizedMessage}"
                    return@launch
                }
            } else {
                ProceduralGenerator.generateNation(
                    customName = hint.ifBlank { null },
                    cultureId = bundle.cultures.firstOrNull()?.id.orEmpty(),
                    religionId = bundle.religions.firstOrNull()?.id.orEmpty(),
                    languageId = bundle.languages.firstOrNull()?.id.orEmpty()
                )
            }
            repository.saveNation(currentUserId, worldId, nation)
                .onSuccess { _feedbackMessage.value = "国家「${nation.name}」を建国しました。" }
                .onFailure { _feedbackMessage.value = it.localizedMessage }
        }
    }

    fun saveNation(nation: Nation) {
        viewModelScope.launch {
            repository.saveNation(currentUserId, worldId, nation)
                .onFailure { _feedbackMessage.value = it.localizedMessage }
        }
    }

    fun placeOrCreateVillage(mapX: Long, mapY: Long, nationId: String = "", customName: String? = null) {
        val bundle = currentBundle() ?: return
        val resolvedNation = nationId.ifBlank { bundle.nations.firstOrNull()?.id.orEmpty() }
        val village = ProceduralGenerator.generateVillage(
            customName = customName?.ifBlank { null },
            nationId = resolvedNation,
            mapX = mapX,
            mapY = mapY
        )
        viewModelScope.launch {
            repository.saveVillage(currentUserId, worldId, village)
                .onSuccess { _feedbackMessage.value = "村「${village.name}」を開拓しました。" }
                .onFailure { _feedbackMessage.value = it.localizedMessage }
        }
    }

    fun saveVillage(village: Village) {
        viewModelScope.launch {
            repository.saveVillage(currentUserId, worldId, village)
                .onFailure { _feedbackMessage.value = it.localizedMessage }
        }
    }

    fun updateDistrictCell(village: Village, gx: Int, gy: Int, type: DistrictType?, label: String) {
        val cells = village.districtCells.mapNotNull { WorldCodecs.decodeDistrictCell(it) }.toMutableList()
        cells.removeAll { it.x == gx && it.y == gy }
        if (type != null) {
            val existingLevel = village.districtCells
                .mapNotNull { WorldCodecs.decodeDistrictCell(it) }
                .firstOrNull { it.x == gx && it.y == gy }?.level ?: 0
            val nextLevel = if (existingLevel > 0) (existingLevel + 1).coerceAtMost(5) else 1
            cells.add(DistrictCell(gx, gy, type, nextLevel, label.ifBlank { type.label }))
        }
        val encoded = cells.take(48).map { WorldCodecs.encodeDistrictCell(it) }
        val bonusPop = if (type != null) 25L else 0L
        saveVillage(
            village.copy(
                districtCells = encoded,
                population = (village.population + bonusPop).coerceAtMost(10_000_000L),
                prosperity = (village.prosperity + 2L).coerceIn(0L, 100L)
            )
        )
    }

    fun createPerson(mode: GenerationMode, village: Village, districtType: DistrictType) {
        val bundle = currentBundle() ?: return
        val nation = bundle.nations.firstOrNull { it.id == village.nationId }
        val language = bundle.languages.firstOrNull { it.id == nation?.languageId } ?: bundle.languages.firstOrNull()
        val religion = bundle.religions.firstOrNull { it.id == nation?.religionId } ?: bundle.religions.firstOrNull()
        viewModelScope.launch {
            val person = if (mode == GenerationMode.AI) {
                _isGenerating.value = true
                val res = aiGenerator.generatePersonAi(bundle.world, village, language, religion, districtType)
                _isGenerating.value = false
                res.getOrElse { err ->
                    _feedbackMessage.value = "AI創世エラー: ${err.localizedMessage}"
                    return@launch
                }
            } else {
                ProceduralGenerator.generatePerson(
                    villageId = village.id,
                    nationId = village.nationId,
                    language = language,
                    faithName = religion?.name ?: "星辰の理",
                    districtType = districtType
                )
            }
            repository.savePerson(currentUserId, worldId, person)
                .onSuccess { _feedbackMessage.value = "住民「${person.name}」が誕生しました。" }
                .onFailure { _feedbackMessage.value = it.localizedMessage }
        }
    }

    fun savePerson(person: Person) {
        viewModelScope.launch {
            repository.savePerson(currentUserId, worldId, person)
                .onFailure { _feedbackMessage.value = it.localizedMessage }
        }
    }

    fun createChronicle(mode: GenerationMode, category: String = "歴史", title: String = "", summary: String = "") {
        val bundle = currentBundle() ?: return
        viewModelScope.launch {
            val chronicle = if (mode == GenerationMode.AI && title.isBlank()) {
                _isGenerating.value = true
                val res = aiGenerator.generateChronicleAi(bundle.world, bundle)
                _isGenerating.value = false
                res.getOrElse { err ->
                    _feedbackMessage.value = "AI創世エラー: ${err.localizedMessage}"
                    return@launch
                }
            } else {
                Chronicle(
                    year = bundle.world.currentYear,
                    category = category,
                    title = title.ifBlank { "${bundle.world.name}の新記録" },
                    summary = summary.ifBlank { "人々の営みが歴史に刻まれた。" }
                )
            }
            repository.saveChronicle(currentUserId, worldId, chronicle)
                .onSuccess { _feedbackMessage.value = "年表に「${chronicle.title}」を刻みました。" }
                .onFailure { _feedbackMessage.value = it.localizedMessage }
        }
    }

    fun deleteEntity(subcollection: String, docId: String) {
        viewModelScope.launch {
            repository.deleteSubdocument(currentUserId, worldId, subcollection, docId)
                .onFailure { _feedbackMessage.value = it.localizedMessage }
        }
    }

    private companion object {
        const val TAG = "SandboxVM"
    }
}
