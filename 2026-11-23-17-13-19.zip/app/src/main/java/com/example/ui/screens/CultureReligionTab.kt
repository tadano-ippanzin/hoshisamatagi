package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.TempleBuddhist
import androidx.compose.material.icons.filled.TheaterComedy
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.Culture
import com.example.model.GenerationMode
import com.example.model.Religion
import com.example.model.WorldBundle
import com.example.ui.components.SacredEmblemView

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CultureReligionTab(
    bundle: WorldBundle,
    generationMode: GenerationMode,
    isGenerating: Boolean,
    onCreateCulture: (GenerationMode, String) -> Unit,
    onSaveCulture: (Culture) -> Unit,
    onCreateReligion: (GenerationMode, String) -> Unit,
    onSaveReligion: (Religion) -> Unit,
    onDeleteEntity: (String, String) -> Unit
) {
    var subTab by remember { mutableIntStateOf(0) } // 0 = 文化, 1 = 宗教
    var editingCulture by remember { mutableStateOf<Culture?>(null) }
    var editingReligion by remember { mutableStateOf<Religion?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = subTab) {
            Tab(
                selected = subTab == 0,
                onClick = { subTab = 0 },
                text = { Text("文化・習俗 (${bundle.cultures.size})") },
                icon = { Icon(Icons.Filled.TheaterComedy, contentDescription = null) }
            )
            Tab(
                selected = subTab == 1,
                onClick = { subTab = 1 },
                text = { Text("宗教・神話 (${bundle.religions.size})") },
                icon = { Icon(Icons.Filled.TempleBuddhist, contentDescription = null) }
            )
        }

        if (subTab == 0) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Button(
                        onClick = { onCreateCulture(generationMode, "") },
                        enabled = !isGenerating,
                        modifier = Modifier.fillMaxWidth().testTag("create_culture_button")
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("${generationMode.shortLabel}で文化を創る")
                    }
                }
                items(bundle.cultures, key = { it.id }) { cul ->
                    val langName = bundle.languages.firstOrNull { it.id == cul.languageId }?.name ?: "未設定"
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(cul.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text("使用言語: $langName ・ 気風: ${cul.ethos}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                }
                                IconButton(onClick = { editingCulture = cul }, modifier = Modifier.minimumInteractiveComponentSize()) {
                                    Icon(Icons.Filled.Edit, contentDescription = "文化を編集")
                                }
                                IconButton(onClick = { onDeleteEntity("cultures", cul.id) }, modifier = Modifier.minimumInteractiveComponentSize()) {
                                    Icon(Icons.Filled.Delete, contentDescription = "${cul.name}を削除")
                                }
                            }
                            Text("建築様式: ${cul.architectureStyle}", style = MaterialTheme.typography.bodySmall)
                            Text("食文化: ${cul.cuisine}", style = MaterialTheme.typography.bodySmall)
                            Text("祭礼: ${cul.festival} / 挨拶: 「${cul.greeting}」", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Button(
                        onClick = { onCreateReligion(generationMode, "") },
                        enabled = !isGenerating,
                        modifier = Modifier.fillMaxWidth().testTag("create_religion_button")
                    ) {
                        Icon(Icons.Filled.AutoFixHigh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("${generationMode.shortLabel}で宗教・創世神話を生む")
                    }
                }
                items(bundle.religions, key = { it.id }) { rel ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                SacredEmblemView(
                                    sides = rel.emblemSides.toInt(),
                                    color = Color(rel.emblemColorHex),
                                    modifier = Modifier.size(56.dp)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(rel.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text(rel.cosmologyType, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                    if (rel.deityConcept.isNotBlank()) {
                                        Text(rel.deityConcept, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                                IconButton(onClick = { editingReligion = rel }, modifier = Modifier.minimumInteractiveComponentSize()) {
                                    Icon(Icons.Filled.Edit, contentDescription = "宗教を編集")
                                }
                                IconButton(onClick = { onDeleteEntity("religions", rel.id) }, modifier = Modifier.minimumInteractiveComponentSize()) {
                                    Icon(Icons.Filled.Delete, contentDescription = "${rel.name}を削除")
                                }
                            }
                            if (rel.tenets.isNotBlank()) {
                                Text("教義・規範: ${rel.tenets}", style = MaterialTheme.typography.bodySmall)
                            }
                            if (rel.rituals.isNotBlank()) {
                                Text("儀式: ${rel.rituals}", style = MaterialTheme.typography.bodySmall)
                            }
                            if (rel.creationMyth.isNotBlank()) {
                                Text(
                                    text = "創世神話: ${rel.creationMyth}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    editingCulture?.let { cul ->
        var name by remember { mutableStateOf(cul.name) }
        var ethos by remember { mutableStateOf(cul.ethos) }
        var arch by remember { mutableStateOf(cul.architectureStyle) }
        var cuisine by remember { mutableStateOf(cul.cuisine) }
        var festival by remember { mutableStateOf(cul.festival) }
        var greeting by remember { mutableStateOf(cul.greeting) }
        var langId by remember { mutableStateOf(cul.languageId) }

        AlertDialog(
            onDismissRequest = { editingCulture = null },
            title = { Text("文化の編集") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("文化名") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = ethos, onValueChange = { ethos = it }, label = { Text("価値観・気風") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = arch, onValueChange = { arch = it }, label = { Text("建築様式") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = cuisine, onValueChange = { cuisine = it }, label = { Text("食文化") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = festival, onValueChange = { festival = it }, label = { Text("祭礼") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = greeting, onValueChange = { greeting = it }, label = { Text("挨拶") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    if (bundle.languages.isNotEmpty()) {
                        Text("対応言語", style = MaterialTheme.typography.labelSmall)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            bundle.languages.forEach { l ->
                                FilterChip(selected = langId == l.id, onClick = { langId = l.id }, label = { Text(l.name) })
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    onSaveCulture(
                        cul.copy(
                            name = name,
                            ethos = ethos,
                            architectureStyle = arch,
                            cuisine = cuisine,
                            festival = festival,
                            greeting = greeting,
                            languageId = langId
                        )
                    )
                    editingCulture = null
                }) { Text("保存") }
            },
            dismissButton = { TextButton(onClick = { editingCulture = null }) { Text("閉じる") } }
        )
    }

    editingReligion?.let { rel ->
        var name by remember { mutableStateOf(rel.name) }
        var deity by remember { mutableStateOf(rel.deityConcept) }
        var tenets by remember { mutableStateOf(rel.tenets) }
        var myth by remember { mutableStateOf(rel.creationMyth) }
        var sides by remember { mutableFloatStateOf(rel.emblemSides.toFloat()) }

        AlertDialog(
            onDismissRequest = { editingReligion = null },
            title = { Text("宗教・聖印の編集") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        SacredEmblemView(sides = sides.toInt(), color = Color(rel.emblemColorHex), modifier = Modifier.size(52.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("聖印の角数: ${sides.toInt()}角形", style = MaterialTheme.typography.labelMedium)
                            Slider(value = sides, onValueChange = { sides = it }, valueRange = 3f..10f, steps = 6)
                        }
                    }
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("宗教名") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = deity, onValueChange = { deity = it }, label = { Text("信仰対象") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = tenets, onValueChange = { tenets = it }, label = { Text("教義") }, maxLines = 2, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = myth, onValueChange = { myth = it }, label = { Text("創世神話") }, maxLines = 3, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(onClick = {
                    onSaveReligion(rel.copy(name = name, deityConcept = deity, tenets = tenets, creationMyth = myth, emblemSides = sides.toLong()))
                    editingReligion = null
                }) { Text("保存") }
            },
            dismissButton = { TextButton(onClick = { editingReligion = null }) { Text("閉じる") } }
        )
    }
}
