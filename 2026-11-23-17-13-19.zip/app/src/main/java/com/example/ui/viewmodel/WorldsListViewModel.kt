package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.WorldRepository
import com.example.model.UiState
import com.example.model.World
import com.example.ui.theme.VisualThemeMode
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class WorldsListViewModel(
    private val repository: WorldRepository,
    private val currentUserId: String
) : ViewModel() {

    val worldsState: StateFlow<UiState<List<World>>> = repository.observeWorlds(currentUserId)
        .map<List<World>, UiState<List<World>>> { UiState.Success(it) }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing worlds", rootError)
            emit(UiState.Error(rootError.message ?: "星データの読み込みに失敗しました。"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = UiState.Loading
        )

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _actionMessage = MutableStateFlow<String?>(null)
    val actionMessage: StateFlow<String?> = _actionMessage.asStateFlow()

    fun clearMessage() {
        _actionMessage.value = null
    }

    fun createWorld(
        name: String,
        starType: String,
        description: String,
        visualTheme: VisualThemeMode,
        includeStarterContent: Boolean,
        onCreated: (String) -> Unit
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            val result = repository.createWorld(
                userId = currentUserId,
                name = name,
                starType = starType,
                description = description,
                visualTheme = visualTheme,
                includeStarterContent = includeStarterContent
            )
            _isBusy.value = false
            result.onSuccess { worldId ->
                onCreated(worldId)
            }.onFailure { err ->
                _actionMessage.value = err.localizedMessage ?: "星の作成に失敗しました。"
            }
        }
    }

    fun deleteWorld(worldId: String) {
        viewModelScope.launch {
            _isBusy.value = true
            val result = repository.deleteWorld(currentUserId, worldId)
            _isBusy.value = false
            result.onFailure { err ->
                _actionMessage.value = err.localizedMessage ?: "星の削除に失敗しました。"
            }
        }
    }

    private companion object {
        const val TAG = "WorldsListVM"
    }
}
