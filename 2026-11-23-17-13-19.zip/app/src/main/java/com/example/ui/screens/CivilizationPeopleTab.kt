package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.People
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.DistrictType
import com.example.model.GenerationMode
import com.example.model.Nation
import com.example.model.Person
import com.example.model.Village
import com.example.model.WorldBundle
import com.example.model.WorldCodecs

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CivilizationPeopleTab(
    bundle: WorldBundle,
    generationMode: GenerationMode,
    isGenerating: Boolean,
    onCreateNation: (GenerationMode, String) -> Unit,
    onSaveNation: (Nation) -> Unit,
    onOpenVillage: (Village) -> Unit,
    onCreateVillage: (Long, Long, String, String) -> Unit,
    onCreatePerson: (GenerationMode, Village, DistrictType) -> Unit,
    onSavePerson: (Person) -> Unit,
    onCreateChronicle: (GenerationMode, String, String, String) -> Unit,
    onDeleteEntity: (String, String) -> Unit
) {
    var subTab by remember { mutableIntStateOf(0) } // 0=国, 1=村・区画, 2=人々, 3=世界年表
    var editingNation by remember { mutableStateOf<Nation?>(null) }
    var editingPerson by remember { mutableStateOf<Person?>(null) }
    var showManualChronicle by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        ScrollableTabRow(selectedTabIndex = subTab, edgePadding = 12.dp) {
            Tab(
                selected = subTab == 0,
                onClick = { subTab = 0 },
                text = { Text("国 (${bundle.nations.size})") },
                icon = { Icon(Icons.Filled.Flag, contentDescription = null) }
            )
            Tab(
                selected = subTab == 1,
                onClick = { subTab = 1 },
                text = { Text("村・区画 (${bundle.villages.size})") },
                icon = { Icon(Icons.Filled.LocationCity, contentDescription = null) }
            )
            Tab(
                selected = subTab == 2,
                onClick = { subTab = 2 },
                text = { Text("人々 (${bundle.people.size})") },
                icon = { Icon(Icons.Filled.People, contentDescription = null) }
            )
            Tab(
                selected = subTab == 3,
                onClick = { subTab = 3 },
                text = { Text("世界年表 (${bundle.chronicles.size})") },
                icon = { Icon(Icons.Filled.HistoryEdu, contentDescription = null) }
            )
        }

        when (subTab) {
            0 -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Button(
                            onClick = { onCreateNation(generationMode, "") },
                            enabled = !isGenerating,
                            modifier = Modifier.fillMaxWidth().testTag("create_nation_button")
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("${generationMode.shortLabel}で新しい国を建てる")
                        }
                    }
                    items(bundle.nations, key = { it.id }) { nation ->
                        val cul = bundle.cultures.firstOrNull { it.id == nation.cultureId }?.name ?: "未設定"
                        val rel = bundle.religions.firstOrNull { it.id == nation.religionId }?.name ?: "未設定"
                        val lang = bundle.languages.firstOrNull { it.id == nation.languageId }?.name ?: "未設定"
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(20.dp)
                                            .clip(CircleShape)
                                            .background(Color(nation.colorHex))
                                    )
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(nation.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text(nation.governmentType, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                    }
                                    IconButton(onClick = { editingNation = nation }, modifier = Modifier.minimumInteractiveComponentSize()) {
                                        Icon(Icons.Filled.Edit, contentDescription = "国を編集")
                                    }
                                    IconButton(onClick = { onDeleteEntity("nations", nation.id) }, modifier = Modifier.minimumInteractiveComponentSize()) {
                                        Icon(Icons.Filled.Delete, contentDescription = "${nation.name}を削除")
                                    }
                                }
                                Text("文化: $cul / 宗教: $rel / 言語: $lang", style = MaterialTheme.typography.bodySmall)
                                if (nation.motto.isNotBlank()) {
                                    Text("国是: 「${nation.motto}」", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Button(
                            onClick = {
                                val rx = (bundle.villages.size * 3 + 2) % bundle.world.gridWidth.toInt().coerceAtLeast(1)
                                val ry = (bundle.villages.size * 2 + 3) % bundle.world.gridHeight.toInt().coerceAtLeast(1)
                                onCreateVillage(rx.toLong(), ry.toLong(), bundle.nations.firstOrNull()?.id.orEmpty(), "")
                            },
                            modifier = Modifier.fillMaxWidth().testTag("create_village_button")
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("新しい村を開拓する")
                        }
                    }
                    items(bundle.villages, key = { it.id }) { vil ->
                        val nationName = bundle.nations.firstOrNull { it.id == vil.nationId }?.name ?: "独立集落"
                        val districtCount = vil.districtCells.mapNotNull { WorldCodecs.decodeDistrictCell(it) }.size
                        Card(
                            onClick = { onOpenVillage(vil) },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(vil.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text(
                                        "$nationName ・ 人口 ${vil.population}人 ・ 区画 ${districtCount}/36",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    if (vil.specialty.isNotBlank()) {
                                        Text(vil.specialty, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                OutlinedButton(onClick = { onOpenVillage(vil) }) {
                                    Text("区画を見る")
                                }
                                IconButton(onClick = { onDeleteEntity("villages", vil.id) }, modifier = Modifier.minimumInteractiveComponentSize()) {
                                    Icon(Icons.Filled.Delete, contentDescription = "${vil.name}を削除")
                                }
                            }
                        }
                    }
                }
            }

            2 -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        val targetVillage = bundle.villages.firstOrNull()
                        if (targetVillage != null) {
                            Button(
                                onClick = { onCreatePerson(generationMode, targetVillage, DistrictType.entries.random()) },
                                enabled = !isGenerating,
                                modifier = Modifier.fillMaxWidth().testTag("create_person_button")
                            ) {
                                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("${generationMode.shortLabel}で住民を創る (${targetVillage.name})")
                            }
                        } else {
                            Text(
                                text = "住民を誕生させるには、まず「村・区画」または「惑星地図」で村を1つ作成してください。",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    items(bundle.people, key = { it.id }) { p ->
                        val vilName = bundle.villages.firstOrNull { it.id == p.villageId }?.name ?: "旅人"
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("${p.name}（${p.age}歳）", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                    Text(
                                        "$vilName ・ ${DistrictType.fromKey(p.districtType).label} ・ ${p.role}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text("気質: ${p.traits} ・ 信仰: ${p.faith}", style = MaterialTheme.typography.bodySmall)
                                    if (p.biography.isNotBlank()) {
                                        Text(p.biography, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                IconButton(onClick = { editingPerson = p }, modifier = Modifier.minimumInteractiveComponentSize()) {
                                    Icon(Icons.Filled.Edit, contentDescription = "住民を編集")
                                }
                                IconButton(onClick = { onDeleteEntity("people", p.id) }, modifier = Modifier.minimumInteractiveComponentSize()) {
                                    Icon(Icons.Filled.Delete, contentDescription = "${p.name}を削除")
                                }
                            }
                        }
                    }
                }
            }

            3 -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { onCreateChronicle(generationMode, "歴史", "", "") },
                                enabled = !isGenerating,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("${generationMode.shortLabel}で歴史イベント発生")
                            }
                            OutlinedButton(
                                onClick = { showManualChronicle = true },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("年表に手記を刻む")
                            }
                        }
                    }
                    items(bundle.chronicles, key = { it.id }) { ch ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.Top,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        "${bundle.world.eraName} ${ch.year}年 ［${ch.category}］",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(ch.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                    if (ch.summary.isNotBlank()) {
                                        Text(ch.summary, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                                IconButton(onClick = { onDeleteEntity("chronicles", ch.id) }, modifier = Modifier.minimumInteractiveComponentSize()) {
                                    Icon(Icons.Filled.Delete, contentDescription = "年表を削除")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    editingNation?.let { n ->
        var name by remember { mutableStateOf(n.name) }
        var gov by remember { mutableStateOf(n.governmentType) }
        var motto by remember { mutableStateOf(n.motto) }
        var cId by remember { mutableStateOf(n.cultureId) }
        var rId by remember { mutableStateOf(n.religionId) }
        var lId by remember { mutableStateOf(n.languageId) }

        AlertDialog(
            onDismissRequest = { editingNation = null },
            title = { Text("国家の設定") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("国名") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = gov, onValueChange = { gov = it }, label = { Text("政治体制") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = motto, onValueChange = { motto = it }, label = { Text("国是・標語") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    if (bundle.cultures.isNotEmpty()) {
                        Text("主要文化", style = MaterialTheme.typography.labelSmall)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            bundle.cultures.forEach { c -> FilterChip(selected = cId == c.id, onClick = { cId = c.id }, label = { Text(c.name) }) }
                        }
                    }
                    if (bundle.religions.isNotEmpty()) {
                        Text("国教・主要信仰", style = MaterialTheme.typography.labelSmall)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            bundle.religions.forEach { r -> FilterChip(selected = rId == r.id, onClick = { rId = r.id }, label = { Text(r.name) }) }
                        }
                    }
                    if (bundle.languages.isNotEmpty()) {
                        Text("公用語", style = MaterialTheme.typography.labelSmall)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            bundle.languages.forEach { l -> FilterChip(selected = lId == l.id, onClick = { lId = l.id }, label = { Text(l.name) }) }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    onSaveNation(n.copy(name = name, governmentType = gov, motto = motto, cultureId = cId, religionId = rId, languageId = lId))
                    editingNation = null
                }) { Text("保存") }
            },
            dismissButton = { TextButton(onClick = { editingNation = null }) { Text("閉じる") } }
        )
    }

    editingPerson?.let { p ->
        var name by remember { mutableStateOf(p.name) }
        var role by remember { mutableStateOf(p.role) }
        var traits by remember { mutableStateOf(p.traits) }
        var bio by remember { mutableStateOf(p.biography) }
        AlertDialog(
            onDismissRequest = { editingPerson = null },
            title = { Text("人物の設定") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("名前") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = role, onValueChange = { role = it }, label = { Text("職業・役割") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = traits, onValueChange = { traits = it }, label = { Text("性格") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = bio, onValueChange = { bio = it }, label = { Text("伝記・記録") }, maxLines = 3, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(onClick = {
                    onSavePerson(p.copy(name = name, role = role, traits = traits, biography = bio))
                    editingPerson = null
                }) { Text("保存") }
            },
            dismissButton = { TextButton(onClick = { editingPerson = null }) { Text("閉じる") } }
        )
    }

    if (showManualChronicle) {
        var cat by remember { mutableStateOf("創世") }
        var title by remember { mutableStateOf("") }
        var summary by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showManualChronicle = false },
            title = { Text("年表に出来事を刻む") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = cat, onValueChange = { cat = it }, label = { Text("分類") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("見出し") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = summary, onValueChange = { summary = it }, label = { Text("内容") }, maxLines = 3, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(onClick = {
                    onCreateChronicle(GenerationMode.PROCEDURAL, cat, title, summary)
                    showManualChronicle = false
                }) { Text("記録") }
            },
            dismissButton = { TextButton(onClick = { showManualChronicle = false }) { Text("閉じる") } }
        )
    }
}
