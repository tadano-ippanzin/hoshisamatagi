package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.TempleBuddhist
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.GenerationMode
import com.example.model.UiState
import com.example.model.World
import com.example.model.WorldBundle
import com.example.ui.components.GenerationModeSelector
import com.example.ui.components.ThemePickerButton
import com.example.ui.theme.VisualThemeMode
import com.example.ui.viewmodel.SandboxViewModel

private data class NavTabItem(
    val index: Int,
    val label: String,
    val icon: ImageVector
)

private val SANDBOX_TABS = listOf(
    NavTabItem(0, "惑星地図", Icons.Filled.Public),
    NavTabItem(1, "元素生態", Icons.Filled.Science),
    NavTabItem(2, "言語文字", Icons.Filled.Translate),
    NavTabItem(3, "文化宗教", Icons.Filled.TempleBuddhist),
    NavTabItem(4, "国村人々", Icons.Filled.LocationCity)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SandboxWorkspaceScreen(
    viewModel: SandboxViewModel,
    themeMode: VisualThemeMode,
    generationMode: GenerationMode,
    onSelectTheme: (VisualThemeMode) -> Unit,
    onSelectGenerationMode: (GenerationMode) -> Unit,
    onBackToWorlds: () -> Unit
) {
    BackHandler { onBackToWorlds() }

    val bundleState by viewModel.bundleState.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()
    val feedbackMessage by viewModel.feedbackMessage.collectAsStateWithLifecycle()
    val clockSpeed by viewModel.clockSpeed.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) }
    var openedVillageId by remember { mutableStateOf<String?>(null) }
    var editingWorldMeta by remember { mutableStateOf<World?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(feedbackMessage) {
        val msg = feedbackMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearFeedback()
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 720.dp

        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            contentWindowInsets = WindowInsets.navigationBars,
            topBar = {
                Column {
                    TopAppBar(
                        navigationIcon = {
                            IconButton(
                                onClick = onBackToWorlds,
                                modifier = Modifier.minimumInteractiveComponentSize().testTag("back_to_worlds_button")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "星一覧に戻る")
                            }
                        },
                        title = {
                            val world = (bundleState as? UiState.Success)?.data?.world
                            Column {
                                Text(
                                    text = world?.name ?: "創世中...",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (world != null) {
                                    Text(
                                        text = "${world.eraName} ${world.currentYear}年 ・ ${world.starType}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        },
                        actions = {
                            GenerationModeSelector(
                                mode = generationMode,
                                onModeChange = onSelectGenerationMode
                            )
                            ThemePickerButton(
                                currentTheme = themeMode,
                                onSelectTheme = { mode ->
                                    onSelectTheme(mode)
                                    viewModel.updateWorldTheme(mode)
                                }
                            )
                        }
                    )

                    // Compact World Simulation & Era Bar
                    val world = (bundleState as? UiState.Success)?.data?.world
                    if (world != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                FilterChip(
                                    selected = clockSpeed == 0,
                                    onClick = { viewModel.setClockSpeed(0) },
                                    leadingIcon = { Icon(Icons.Filled.Pause, contentDescription = null, modifier = Modifier.size(14.dp)) },
                                    label = { Text("停止", style = MaterialTheme.typography.labelSmall) }
                                )
                                FilterChip(
                                    selected = clockSpeed == 1,
                                    onClick = { viewModel.setClockSpeed(1) },
                                    leadingIcon = { Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp)) },
                                    label = { Text("1x", style = MaterialTheme.typography.labelSmall) }
                                )
                                FilterChip(
                                    selected = clockSpeed == 3,
                                    onClick = { viewModel.setClockSpeed(3) },
                                    leadingIcon = { Icon(Icons.Filled.FastForward, contentDescription = null, modifier = Modifier.size(14.dp)) },
                                    label = { Text("3x", style = MaterialTheme.typography.labelSmall) }
                                )
                                TextButton(
                                    onClick = {
                                        viewModel.advanceTime(10L, useAiChronicle = generationMode == GenerationMode.AI)
                                    },
                                    enabled = !isGenerating,
                                    modifier = Modifier.testTag("advance_era_button")
                                ) {
                                    Icon(Icons.Filled.SkipNext, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(2.dp))
                                    Text("+10年", style = MaterialTheme.typography.labelMedium)
                                }
                                Spacer(Modifier.weight(1f))
                                TextButton(onClick = { editingWorldMeta = world }) {
                                    Text("星設定", style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                    }

                    if (isGenerating) {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }
                }
            },
            bottomBar = {
                if (!useRail) {
                    NavigationBar {
                        SANDBOX_TABS.forEach { tab ->
                            NavigationBarItem(
                                selected = selectedTab == tab.index,
                                onClick = { selectedTab = tab.index },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label, maxLines = 1) },
                                modifier = Modifier.testTag("nav_tab_${tab.index}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(modifier = Modifier.fillMaxHeight()) {
                        SANDBOX_TABS.forEach { tab ->
                            NavigationRailItem(
                                selected = selectedTab == tab.index,
                                onClick = { selectedTab = tab.index },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label) },
                                modifier = Modifier.testTag("nav_rail_${tab.index}")
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    when (val state = bundleState) {
                        is UiState.Loading -> {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator()
                            }
                        }
                        is UiState.Error -> {
                            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    text = state.message,
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodyLarge
                                )
                            }
                        }
                        is UiState.Success -> {
                            val bundle: WorldBundle = state.data
                            when (selectedTab) {
                                0 -> PlanetMapTab(
                                    bundle = bundle,
                                    onPaintBiome = viewModel::paintTerrainTile,
                                    onPaintNation = viewModel::paintNationTile,
                                    onPlaceVillage = { x, y, nId, name ->
                                        viewModel.placeOrCreateVillage(x.toLong(), y.toLong(), nId, name)
                                    },
                                    onRegenerateTerrain = viewModel::regenerateTerrain,
                                    onOpenVillage = { v -> openedVillageId = v.id }
                                )
                                1 -> MatterLifeTab(
                                    bundle = bundle,
                                    generationMode = generationMode,
                                    isGenerating = isGenerating,
                                    onCreateElement = viewModel::createOrGenerateElement,
                                    onSaveElement = viewModel::saveElement,
                                    onSynthesizeElements = viewModel::synthesizeElements,
                                    onCreateEcosystem = viewModel::createEcosystemAndSpecies,
                                    onCreateSpecies = viewModel::createSpecies,
                                    onDeleteEntity = viewModel::deleteEntity
                                )
                                2 -> LanguageScriptTab(
                                    bundle = bundle,
                                    generationMode = generationMode,
                                    isGenerating = isGenerating,
                                    onCreateLanguage = viewModel::createLanguage,
                                    onSaveLanguage = viewModel::saveLanguage,
                                    onUpdateGlyph = viewModel::updateLanguageGlyph,
                                    onAddWord = viewModel::addWordToLanguage,
                                    onDeleteEntity = viewModel::deleteEntity
                                )
                                3 -> CultureReligionTab(
                                    bundle = bundle,
                                    generationMode = generationMode,
                                    isGenerating = isGenerating,
                                    onCreateCulture = viewModel::createCulture,
                                    onSaveCulture = viewModel::saveCulture,
                                    onCreateReligion = viewModel::createReligion,
                                    onSaveReligion = viewModel::saveReligion,
                                    onDeleteEntity = viewModel::deleteEntity
                                )
                                4 -> CivilizationPeopleTab(
                                    bundle = bundle,
                                    generationMode = generationMode,
                                    isGenerating = isGenerating,
                                    onCreateNation = viewModel::createNation,
                                    onSaveNation = viewModel::saveNation,
                                    onOpenVillage = { v -> openedVillageId = v.id },
                                    onCreateVillage = viewModel::placeOrCreateVillage,
                                    onCreatePerson = viewModel::createPerson,
                                    onSavePerson = viewModel::savePerson,
                                    onCreateChronicle = viewModel::createChronicle,
                                    onDeleteEntity = viewModel::deleteEntity
                                )
                            }

                            val activeVillage = bundle.villages.firstOrNull { it.id == openedVillageId }
                            if (activeVillage != null) {
                                VillageDistrictSheet(
                                    village = activeVillage,
                                    nations = bundle.nations,
                                    peopleInVillage = bundle.people.filter { it.villageId == activeVillage.id },
                                    generationMode = generationMode,
                                    isGenerating = isGenerating,
                                    onDismiss = { openedVillageId = null },
                                    onSaveVillage = viewModel::saveVillage,
                                    onUpdateDistrictCell = { gx, gy, type, label ->
                                        viewModel.updateDistrictCell(activeVillage, gx, gy, type, label)
                                    },
                                    onCreatePerson = { districtType ->
                                        viewModel.createPerson(generationMode, activeVillage, districtType)
                                    },
                                    onDeletePerson = { personId ->
                                        viewModel.deleteEntity("people", personId)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    editingWorldMeta?.let { world ->
        var wName by remember { mutableStateOf(world.name) }
        var wStar by remember { mutableStateOf(world.starType) }
        var wEra by remember { mutableStateOf(world.eraName) }
        var wDesc by remember { mutableStateOf(world.description) }
        AlertDialog(
            onDismissRequest = { editingWorldMeta = null },
            title = { Text("星の基本設定") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = wName, onValueChange = { wName = it }, label = { Text("星の名前") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = wStar, onValueChange = { wStar = it }, label = { Text("恒星種別") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = wEra, onValueChange = { wEra = it }, label = { Text("暦・時代名") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = wDesc, onValueChange = { wDesc = it }, label = { Text("惑星の概要") }, maxLines = 3, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.updateWorldMetadata(wName, wStar, wEra, wDesc)
                    editingWorldMeta = null
                }) { Text("保存") }
            },
            dismissButton = { TextButton(onClick = { editingWorldMeta = null }) { Text("閉じる") } }
        )
    }
}
