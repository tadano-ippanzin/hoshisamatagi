package com.example.core

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.GenerationMode
import com.example.ui.theme.VisualThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "hoshitsumugi_prefs")

class ThemePreferences(private val context: Context) {
    private val themeKey = stringPreferencesKey("visual_theme")
    private val genModeKey = stringPreferencesKey("generation_mode")

    val visualThemeFlow: Flow<VisualThemeMode> = context.settingsDataStore.data.map { prefs ->
        val raw = prefs[themeKey]
        VisualThemeMode.entries.firstOrNull { it.name == raw } ?: VisualThemeMode.CELESTIAL_ASTROLABE
    }

    val generationModeFlow: Flow<GenerationMode> = context.settingsDataStore.data.map { prefs ->
        val raw = prefs[genModeKey]
        GenerationMode.entries.firstOrNull { it.name == raw } ?: GenerationMode.PROCEDURAL
    }

    suspend fun setVisualTheme(mode: VisualThemeMode) {
        context.settingsDataStore.edit { prefs ->
            prefs[themeKey] = mode.name
        }
    }

    suspend fun setGenerationMode(mode: GenerationMode) {
        context.settingsDataStore.edit { prefs ->
            prefs[genModeKey] = mode.name
        }
    }
}
