package com.example.data

import android.content.Context
import com.example.R
import com.example.core.OperationType
import com.example.core.handleFirestoreError
import com.example.engine.ProceduralGenerator
import com.example.model.Chronicle
import com.example.model.Culture
import com.example.model.Ecosystem
import com.example.model.Language
import com.example.model.Nation
import com.example.model.Person
import com.example.model.Religion
import com.example.model.Species
import com.example.model.Village
import com.example.model.World
import com.example.model.WorldElement
import com.example.ui.theme.VisualThemeMode
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class WorldRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun verifyUserId(userId: String): String {
        val currentUid = auth.currentUser?.uid
            ?: throw IllegalStateException("Googleログインが必要です。")
        require(currentUid == userId) { "認証ユーザーが一致しません。" }
        return currentUid
    }

    private fun worldDoc(userId: String, worldId: String) =
        db.collection("users").document(userId)
            .collection("worlds").document(worldId)

    private inline fun <reified T> observeSubcollection(
        userId: String,
        worldId: String,
        subcollection: String,
        orderByField: String? = null,
        descending: Boolean = false
    ): Flow<List<T>> {
        val baseRef = worldDoc(userId, worldId).collection(subcollection)
        val query: Query = if (orderByField != null) {
            baseRef.orderBy(
                orderByField,
                if (descending) Query.Direction.DESCENDING else Query.Direction.ASCENDING
            )
        } else {
            baseRef
        }
        return query.snapshots().map { snapshot ->
            snapshot.toObjects(T::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        }
    }

    fun observeWorlds(userId: String): Flow<List<World>> =
        db.collection("users").document(userId).collection("worlds")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(World::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt?.seconds ?: 0L }
            }

    fun observeWorld(userId: String, worldId: String): Flow<World?> =
        worldDoc(userId, worldId).snapshots().map { snapshot ->
            snapshot.toObject(World::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        }

    fun observeElements(userId: String, worldId: String): Flow<List<WorldElement>> =
        observeSubcollection(userId, worldId, "elements")

    fun observeEcosystems(userId: String, worldId: String): Flow<List<Ecosystem>> =
        observeSubcollection(userId, worldId, "ecosystems")

    fun observeSpecies(userId: String, worldId: String): Flow<List<Species>> =
        observeSubcollection(userId, worldId, "species")

    fun observeLanguages(userId: String, worldId: String): Flow<List<Language>> =
        observeSubcollection(userId, worldId, "languages")

    fun observeCultures(userId: String, worldId: String): Flow<List<Culture>> =
        observeSubcollection(userId, worldId, "cultures")

    fun observeReligions(userId: String, worldId: String): Flow<List<Religion>> =
        observeSubcollection(userId, worldId, "religions")

    fun observeNations(userId: String, worldId: String): Flow<List<Nation>> =
        observeSubcollection(userId, worldId, "nations")

    fun observeVillages(userId: String, worldId: String): Flow<List<Village>> =
        observeSubcollection(userId, worldId, "villages")

    fun observePeople(userId: String, worldId: String): Flow<List<Person>> =
        observeSubcollection(userId, worldId, "people")

    fun observeChronicles(userId: String, worldId: String): Flow<List<Chronicle>> =
        observeSubcollection(userId, worldId, "chronicles")

    suspend fun createWorld(
        userId: String,
        name: String,
        starType: String,
        description: String,
        visualTheme: VisualThemeMode,
        includeStarterContent: Boolean
    ): Result<String> {
        val worldId = "w_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "users/$userId/worlds/$worldId"
        return try {
            val uid = verifyUserId(userId)
            val safeName = name.trim().take(60).ifBlank { "無名の星" }
            val safeStar = starType.trim().take(40).ifBlank { "主系列G型星" }
            val safeDesc = description.trim().take(500)
            val width = 16
            val height = 12
            val terrain = if (includeStarterContent) {
                ProceduralGenerator.generatePlanetTerrain(width, height, safeName.hashCode().toLong())
            } else {
                List(width * height) { 352L } // Flat grassy blank canvas ready for sculpting
            }
            val nationGrid = List(width * height) { "" }

            val payload = mapOf(
                "userId" to uid,
                "name" to safeName,
                "starType" to safeStar,
                "description" to safeDesc,
                "currentYear" to 1L,
                "eraName" to "創世紀",
                "gridWidth" to width.toLong(),
                "gridHeight" to height.toLong(),
                "terrainTiles" to terrain,
                "nationGrid" to nationGrid,
                "visualTheme" to visualTheme.name,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            worldDoc(uid, worldId).set(payload).await()

            if (includeStarterContent) {
                seedStarterEntities(uid, worldId, safeName)
            }
            Result.success(worldId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    private suspend fun seedStarterEntities(uid: String, worldId: String, worldName: String) {
        val el1 = ProceduralGenerator.generateElement(1, "星輝鉄", "As", "金属", 42L, 0xFFF4C95DL)
        val el2 = ProceduralGenerator.generateElement(2, "蒼晶素", "Aq", "結晶", 18L, 0xFF38BDF8L)
        saveElement(uid, worldId, el1)
        saveElement(uid, worldId, el2)

        val eco = ProceduralGenerator.generateEcosystem("翡翠樹海", "森林", "温暖湿潤", el1.name)
        val ecoRes = saveEcosystem(uid, worldId, eco)
        val ecoId = ecoRes.getOrNull().orEmpty()

        val sp = ProceduralGenerator.generateSpecies(ecoId, "蒼翼鹿", "草食")
        saveSpecies(uid, worldId, sp)

        val lang = ProceduralGenerator.generateLanguageAndScript("ソラリス語", "星象文字")
        val langId = saveLanguage(uid, worldId, lang).getOrNull().orEmpty()

        val cul = ProceduralGenerator.generateCulture("星詠み文化", langId)
        val culId = saveCulture(uid, worldId, cul).getOrNull().orEmpty()

        val rel = ProceduralGenerator.generateReligion("星辰教", el1.name)
        val relId = saveReligion(uid, worldId, rel).getOrNull().orEmpty()

        val nat = ProceduralGenerator.generateNation("アルカディア評議国", culId, relId, langId)
        val natId = saveNation(uid, worldId, nat).getOrNull().orEmpty()

        val vil = ProceduralGenerator.generateVillage("ルミナ", natId, 7L, 5L)
        val vilId = saveVillage(uid, worldId, vil).getOrNull().orEmpty()

        val person = ProceduralGenerator.generatePerson(vilId, natId, lang, rel.name)
        savePerson(uid, worldId, person)

        val chr = Chronicle(
            userId = uid,
            worldId = worldId,
            year = 1L,
            category = "創世",
            title = "${worldName}の創世",
            summary = "${el1.name}と${el2.name}が大地を織りなし、最初の村${vil.name}に星象文字の灯がともった。"
        )
        saveChronicle(uid, worldId, chr)
    }

    suspend fun updateWorldGridAndMeta(
        userId: String,
        worldId: String,
        name: String? = null,
        starType: String? = null,
        description: String? = null,
        currentYear: Long? = null,
        eraName: String? = null,
        terrainTiles: List<Long>? = null,
        nationGrid: List<String>? = null,
        visualTheme: VisualThemeMode? = null
    ): Result<Unit> {
        val path = "users/$userId/worlds/$worldId"
        return try {
            val uid = verifyUserId(userId)
            val updates = mutableMapOf<String, Any>(
                "updatedAt" to FieldValue.serverTimestamp()
            )
            name?.let { updates["name"] = it.trim().take(60).ifBlank { "無名の星" } }
            starType?.let { updates["starType"] = it.trim().take(40).ifBlank { "主系列星" } }
            description?.let { updates["description"] = it.trim().take(500) }
            currentYear?.let { updates["currentYear"] = it.coerceIn(0L, 100_000_000L) }
            eraName?.let { updates["eraName"] = it.trim().take(60).ifBlank { "星暦" } }
            terrainTiles?.let { updates["terrainTiles"] = it.take(256) }
            nationGrid?.let { updates["nationGrid"] = it.take(256) }
            visualTheme?.let { updates["visualTheme"] = it.name }

            worldDoc(uid, worldId).update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteWorld(userId: String, worldId: String): Result<Unit> {
        val path = "users/$userId/worlds/$worldId"
        return try {
            val uid = verifyUserId(userId)
            worldDoc(uid, worldId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun saveElement(userId: String, worldId: String, element: WorldElement): Result<String> =
        saveSubdocument(
            userId = userId,
            worldId = worldId,
            subcollection = "elements",
            existingId = element.id,
            createFields = mapOf(
                "userId" to userId,
                "worldId" to worldId,
                "name" to element.name.trim().take(60).ifBlank { "新元素" },
                "symbol" to element.symbol.trim().take(8).ifBlank { "El" },
                "atomicNumber" to element.atomicNumber.coerceIn(1L, 999L),
                "category" to element.category.trim().take(30).ifBlank { "基礎元素" },
                "volatility" to element.volatility.coerceIn(0L, 100L),
                "abundance" to element.abundance.coerceIn(0L, 100L),
                "colorHex" to element.colorHex,
                "traits" to element.traits.trim().take(300),
                "compoundFormula" to element.compoundFormula.trim().take(80)
            )
        )

    suspend fun saveEcosystem(userId: String, worldId: String, ecosystem: Ecosystem): Result<String> =
        saveSubdocument(
            userId = userId,
            worldId = worldId,
            subcollection = "ecosystems",
            existingId = ecosystem.id,
            createFields = mapOf(
                "userId" to userId,
                "worldId" to worldId,
                "name" to ecosystem.name.trim().take(60).ifBlank { "新生態系" },
                "biomeType" to ecosystem.biomeType.trim().take(40).ifBlank { "草原" },
                "climate" to ecosystem.climate.trim().take(40).ifBlank { "温暖" },
                "stability" to ecosystem.stability.coerceIn(0L, 100L),
                "foodWebSummary" to ecosystem.foodWebSummary.trim().take(400),
                "keyResource" to ecosystem.keyResource.trim().take(60)
            )
        )

    suspend fun saveSpecies(userId: String, worldId: String, species: Species): Result<String> =
        saveSubdocument(
            userId = userId,
            worldId = worldId,
            subcollection = "species",
            existingId = species.id,
            createFields = mapOf(
                "userId" to userId,
                "worldId" to worldId,
                "ecosystemId" to species.ecosystemId.take(128),
                "name" to species.name.trim().take(60).ifBlank { "未知生物" },
                "trophicRole" to species.trophicRole.trim().take(30).ifBlank { "生産者" },
                "population" to species.population.coerceIn(0L, 100_000_000L),
                "traits" to species.traits.trim().take(300),
                "appearance" to species.appearance.trim().take(300)
            )
        )

    suspend fun saveLanguage(userId: String, worldId: String, language: Language): Result<String> =
        saveSubdocument(
            userId = userId,
            worldId = worldId,
            subcollection = "languages",
            existingId = language.id,
            createFields = mapOf(
                "userId" to userId,
                "worldId" to worldId,
                "name" to language.name.trim().take(60).ifBlank { "新言語" },
                "wordOrder" to language.wordOrder.trim().take(20).ifBlank { "SOV" },
                "vowels" to language.vowels.trim().take(60).ifBlank { "a,e,i,o,u" },
                "consonants" to language.consonants.trim().take(80).ifBlank { "k,s,t,n,r" },
                "syllablePattern" to language.syllablePattern.trim().take(20).ifBlank { "CV" },
                "scriptName" to language.scriptName.trim().take(60).ifBlank { "星象文字" },
                "scriptType" to language.scriptType.trim().take(30).ifBlank { "音素文字" },
                "writingDirection" to language.writingDirection.trim().take(20).ifBlank { "LTR" },
                "lexiconEntries" to language.lexiconEntries.take(80),
                "glyphStrokes" to language.glyphStrokes.take(48),
                "sampleSentence" to language.sampleSentence.trim().take(200)
            )
        )

    suspend fun saveCulture(userId: String, worldId: String, culture: Culture): Result<String> =
        saveSubdocument(
            userId = userId,
            worldId = worldId,
            subcollection = "cultures",
            existingId = culture.id,
            createFields = mapOf(
                "userId" to userId,
                "worldId" to worldId,
                "name" to culture.name.trim().take(60).ifBlank { "新文化" },
                "languageId" to culture.languageId.take(128),
                "ethos" to culture.ethos.trim().take(200),
                "architectureStyle" to culture.architectureStyle.trim().take(120),
                "cuisine" to culture.cuisine.trim().take(120),
                "festival" to culture.festival.trim().take(120),
                "greeting" to culture.greeting.trim().take(120)
            )
        )

    suspend fun saveReligion(userId: String, worldId: String, religion: Religion): Result<String> =
        saveSubdocument(
            userId = userId,
            worldId = worldId,
            subcollection = "religions",
            existingId = religion.id,
            createFields = mapOf(
                "userId" to userId,
                "worldId" to worldId,
                "name" to religion.name.trim().take(60).ifBlank { "新信仰" },
                "cosmologyType" to religion.cosmologyType.trim().take(40).ifBlank { "多神教" },
                "deityConcept" to religion.deityConcept.trim().take(200),
                "tenets" to religion.tenets.trim().take(400),
                "rituals" to religion.rituals.trim().take(300),
                "creationMyth" to religion.creationMyth.trim().take(600),
                "emblemSides" to religion.emblemSides.coerceIn(3L, 12L),
                "emblemColorHex" to religion.emblemColorHex
            )
        )

    suspend fun saveNation(userId: String, worldId: String, nation: Nation): Result<String> =
        saveSubdocument(
            userId = userId,
            worldId = worldId,
            subcollection = "nations",
            existingId = nation.id,
            createFields = mapOf(
                "userId" to userId,
                "worldId" to worldId,
                "name" to nation.name.trim().take(60).ifBlank { "新国家" },
                "governmentType" to nation.governmentType.trim().take(40).ifBlank { "評議会" },
                "cultureId" to nation.cultureId.take(128),
                "religionId" to nation.religionId.take(128),
                "languageId" to nation.languageId.take(128),
                "colorHex" to nation.colorHex,
                "motto" to nation.motto.trim().take(140),
                "diplomacyNote" to nation.diplomacyNote.trim().take(300)
            )
        )

    suspend fun saveVillage(userId: String, worldId: String, village: Village): Result<String> =
        saveSubdocument(
            userId = userId,
            worldId = worldId,
            subcollection = "villages",
            existingId = village.id,
            createFields = mapOf(
                "userId" to userId,
                "worldId" to worldId,
                "nationId" to village.nationId.take(128),
                "name" to village.name.trim().take(60).ifBlank { "新集落" },
                "mapX" to village.mapX.coerceIn(0L, 23L),
                "mapY" to village.mapY.coerceIn(0L, 23L),
                "population" to village.population.coerceIn(0L, 10_000_000L),
                "prosperity" to village.prosperity.coerceIn(0L, 100L),
                "specialty" to village.specialty.trim().take(80),
                "districtCells" to village.districtCells.take(48)
            )
        )

    suspend fun savePerson(userId: String, worldId: String, person: Person): Result<String> =
        saveSubdocument(
            userId = userId,
            worldId = worldId,
            subcollection = "people",
            existingId = person.id,
            createFields = mapOf(
                "userId" to userId,
                "worldId" to worldId,
                "villageId" to person.villageId.take(128),
                "nationId" to person.nationId.take(128),
                "name" to person.name.trim().take(60).ifBlank { "名もなき旅人" },
                "age" to person.age.coerceIn(0L, 10000L),
                "role" to person.role.trim().take(50).ifBlank { "住民" },
                "districtType" to person.districtType.trim().take(40).ifBlank { "RESIDENTIAL" },
                "traits" to person.traits.trim().take(200),
                "faith" to person.faith.trim().take(80),
                "biography" to person.biography.trim().take(500)
            )
        )

    suspend fun saveChronicle(userId: String, worldId: String, chronicle: Chronicle): Result<String> =
        saveSubdocument(
            userId = userId,
            worldId = worldId,
            subcollection = "chronicles",
            existingId = chronicle.id,
            createFields = mapOf(
                "userId" to userId,
                "worldId" to worldId,
                "year" to chronicle.year.coerceIn(0L, 100_000_000L),
                "category" to chronicle.category.trim().take(40).ifBlank { "歴史" },
                "title" to chronicle.title.trim().take(80).ifBlank { "新たな節目" },
                "summary" to chronicle.summary.trim().take(500)
            )
        )

    suspend fun deleteSubdocument(
        userId: String,
        worldId: String,
        subcollection: String,
        docId: String
    ): Result<Unit> {
        val path = "users/$userId/worlds/$worldId/$subcollection/$docId"
        return try {
            val uid = verifyUserId(userId)
            require(docId.isNotBlank()) { "削除対象のIDが指定されていません。" }
            worldDoc(uid, worldId).collection(subcollection).document(docId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    private suspend fun saveSubdocument(
        userId: String,
        worldId: String,
        subcollection: String,
        existingId: String,
        createFields: Map<String, Any>
    ): Result<String> {
        val isNew = existingId.isBlank()
        val docId = if (isNew) {
            "${subcollection.take(3)}_${UUID.randomUUID().toString().replace("-", "").take(14)}"
        } else {
            existingId
        }
        val path = "users/$userId/worlds/$worldId/$subcollection/$docId"
        return try {
            val uid = verifyUserId(userId)
            val docRef = worldDoc(uid, worldId).collection(subcollection).document(docId)
            if (isNew) {
                val payload = createFields.toMutableMap().apply {
                    put("userId", uid)
                    put("worldId", worldId)
                    put("createdAt", FieldValue.serverTimestamp())
                    put("updatedAt", FieldValue.serverTimestamp())
                }
                docRef.set(payload).await()
            } else {
                // Partial update: omit immutable userId, worldId, createdAt
                val updatePayload = createFields.filterKeys {
                    it != "userId" && it != "worldId" && it != "createdAt"
                }.toMutableMap().apply {
                    put("updatedAt", FieldValue.serverTimestamp())
                }
                docRef.update(updatePayload).await()
            }
            Result.success(docId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(
                e,
                if (isNew) OperationType.CREATE else OperationType.UPDATE,
                path
            )
            Result.failure(e)
        }
    }
}
