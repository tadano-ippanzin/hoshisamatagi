package com.example.engine

import android.util.Log
import com.example.model.Chronicle
import com.example.model.Culture
import com.example.model.DistrictType
import com.example.model.Ecosystem
import com.example.model.Language
import com.example.model.Nation
import com.example.model.Person
import com.example.model.Religion
import com.example.model.Species
import com.example.model.Village
import com.example.model.World
import com.example.model.WorldBundle
import com.example.model.WorldCodecs
import com.example.model.WorldElement
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

class AiWorldGenerator {

    private companion object {
        const val TAG = "AiWorldGenerator"
        const val MODEL_NAME = "gemini-3.8-flash"
        const val TIMEOUT_MS = 60_000L
    }

    private suspend fun generateJson(
        prompt: String,
        schema: Schema
    ): Result<JSONObject> {
        return try {
            val model = Firebase.ai.generativeModel(
                modelName = MODEL_NAME,
                generationConfig = generationConfig {
                    responseMimeType = "application/json"
                    responseSchema = schema
                }
            )
            val response = withTimeout(TIMEOUT_MS) {
                model.generateContent(prompt)
            }
            val text = response.text
            if (text.isNullOrBlank()) {
                Result.failure(IllegalStateException("AIモデルが空の応答を返しました。"))
            } else {
                Result.success(JSONObject(text))
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI generation timed out", e)
            Result.failure(IllegalStateException("AI創世が60秒でタイムアウトしました。再度お試しください。"))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "AI generation failed", e)
            Result.failure(e)
        }
    }

    suspend fun generateElementAi(world: World, hint: String): Result<WorldElement> {
        val schema = Schema.obj(
            properties = mapOf(
                "name" to Schema.string("架空の元素名（日本語、12文字以内）"),
                "symbol" to Schema.string("元素記号（英字1〜3文字）"),
                "atomicNumber" to Schema.integer("原子番号（1〜300）"),
                "category" to Schema.string("分類（金属、結晶、気体、霊素、鉱物のいずれか）"),
                "volatility" to Schema.integer("揮発性（0〜100）"),
                "abundance" to Schema.integer("存在比（1〜100）"),
                "traits" to Schema.string("物理・化学的特徴と文明での用途（120文字以内）")
            )
        )
        val prompt = """
            惑星「${world.name}」（恒星種別: ${world.starType}、特徴: ${world.description}）に存在する独創的な元素を1つ創造してください。
            ユーザーのヒント: ${hint.ifBlank { "惑星にふさわしい神秘的で実用的な元素" }}
        """.trimIndent()

        return generateJson(prompt, schema).map { json ->
            val colors = listOf(0xFFF4C95DL, 0xFF38BDF8L, 0xFF34D399L, 0xFFF87171L, 0xFFA78BFAL)
            WorldElement(
                name = json.optString("name", "星輝素").take(60),
                symbol = json.optString("symbol", "As").take(6),
                atomicNumber = json.optLong("atomicNumber", 42L).coerceIn(1L, 999L),
                category = json.optString("category", "結晶").take(30),
                volatility = json.optLong("volatility", 25L).coerceIn(0L, 100L),
                abundance = json.optLong("abundance", 50L).coerceIn(0L, 100L),
                colorHex = colors.random(),
                traits = json.optString("traits", "星光を蓄える特性を持つ").take(300),
                compoundFormula = ""
            )
        }
    }

    suspend fun generateEcosystemAndSpeciesAi(
        world: World,
        bundle: WorldBundle,
        biome: String
    ): Result<Pair<Ecosystem, Species>> {
        val elementNames = bundle.elements.take(5).joinToString("・") { it.name }.ifBlank { "鉄・珪素" }
        val schema = Schema.obj(
            properties = mapOf(
                "ecosystemName" to Schema.string("生態系の名称"),
                "climate" to Schema.string("気候（例: 温暖湿潤、極寒乾燥など）"),
                "foodWebSummary" to Schema.string("食物連鎖と生態循環の説明（180文字以内）"),
                "speciesName" to Schema.string("代表的な固有生物の名前"),
                "trophicRole" to Schema.string("栄養段階（生産者、草食、肉食、分解者のいずれか）"),
                "speciesTraits" to Schema.string("生態や能力の特徴（140文字以内）"),
                "speciesAppearance" to Schema.string("外見の描写（140文字以内）")
            )
        )
        val prompt = """
            惑星「${world.name}」の「${biome}」バイオームに根付く生態系と、その象徴的な固有生物1種を創造してください。
            惑星に存在する元素: $elementNames
        """.trimIndent()

        return generateJson(prompt, schema).map { json ->
            val eco = Ecosystem(
                name = json.optString("ecosystemName", "${biome}の秘境").take(60),
                biomeType = biome.take(40),
                climate = json.optString("climate", "温暖").take(40),
                stability = 82L,
                foodWebSummary = json.optString("foodWebSummary", "").take(400),
                keyResource = bundle.elements.firstOrNull()?.name ?: "星鉱"
            )
            val sp = Species(
                ecosystemId = "",
                name = json.optString("speciesName", "星翼獣").take(60),
                trophicRole = json.optString("trophicRole", "草食").take(30),
                population = 1200L,
                traits = json.optString("speciesTraits", "").take(300),
                appearance = json.optString("speciesAppearance", "").take(300)
            )
            eco to sp
        }
    }

    suspend fun generateLanguageAi(world: World, hint: String): Result<Language> {
        val schema = Schema.obj(
            properties = mapOf(
                "name" to Schema.string("言語の名称"),
                "wordOrder" to Schema.enumeration(listOf("SOV", "SVO", "VSO", "OVS")),
                "vowels" to Schema.string("カンマ区切りの母音リスト（例: a,e,i,o,u）"),
                "consonants" to Schema.string("カンマ区切りの子音リスト（例: k,s,t,n,r,m,l）"),
                "syllablePattern" to Schema.enumeration(listOf("CV", "CVC", "CVV")),
                "scriptName" to Schema.string("この言語を書く独自文字体系の名称"),
                "scriptType" to Schema.enumeration(listOf("音素文字", "音節文字", "表意文字")),
                "writingDirection" to Schema.enumeration(listOf("LTR", "RTL", "TTB")),
                "words" to Schema.array(
                    Schema.obj(
                        properties = mapOf(
                            "word" to Schema.string("音韻に沿った単語（ローマ字表記）"),
                            "meaning" to Schema.string("日本語の意味")
                        )
                    ),
                    description = "基礎語彙8〜10語"
                ),
                "sampleSentence" to Schema.string("上記の語彙を用いた短い挨拶や格言の例文")
            )
        )
        val prompt = """
            惑星「${world.name}」（説明: ${world.description}）で話される架空言語と独自文字体系を設計してください。
            言語の雰囲気ヒント: ${hint.ifBlank { "響きが美しく天体や自然を表す語彙が豊かな言語" }}
        """.trimIndent()

        return generateJson(prompt, schema).map { json ->
            val vowels = json.optString("vowels", "a,e,i,o,u").take(60)
            val consonants = json.optString("consonants", "k,s,t,n,r,m,l").take(80)
            val wordsArr = json.optJSONArray("words")
            val lexicon = mutableListOf<String>()
            if (wordsArr != null) {
                for (i in 0 until minOf(wordsArr.length(), 20)) {
                    val obj = wordsArr.optJSONObject(i) ?: continue
                    val w = obj.optString("word").trim()
                    val m = obj.optString("meaning").trim()
                    if (w.isNotBlank() && m.isNotBlank()) {
                        lexicon.add(WorldCodecs.encodeLexiconEntry(w, m))
                    }
                }
            }
            val glyphKeys = (vowels.split(",") + consonants.split(","))
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .distinct()
                .take(14)
            val glyphs = glyphKeys.map { WorldCodecs.encodeGlyph(ProceduralGenerator.generateProceduralGlyph(it)) }

            Language(
                name = json.optString("name", "星詠み語").take(60),
                wordOrder = json.optString("wordOrder", "SOV").take(20),
                vowels = vowels,
                consonants = consonants,
                syllablePattern = json.optString("syllablePattern", "CV").take(20),
                scriptName = json.optString("scriptName", "星象文字").take(60),
                scriptType = json.optString("scriptType", "音素文字").take(30),
                writingDirection = json.optString("writingDirection", "LTR").take(20),
                lexiconEntries = lexicon,
                glyphStrokes = glyphs,
                sampleSentence = json.optString("sampleSentence", "").take(200)
            )
        }
    }

    suspend fun generateCultureAi(world: World, language: Language?, hint: String): Result<Culture> {
        val schema = Schema.obj(
            properties = mapOf(
                "name" to Schema.string("文化の名称"),
                "ethos" to Schema.string("価値観・気風（80文字以内）"),
                "architectureStyle" to Schema.string("建築様式（60文字以内）"),
                "cuisine" to Schema.string("伝統料理・食文化（60文字以内）"),
                "festival" to Schema.string("代表的な祭礼（40文字以内）"),
                "greeting" to Schema.string("挨拶の言葉（40文字以内）")
            )
        )
        val langContext = language?.let { "使用言語: ${it.name}（例文: ${it.sampleSentence}）" } ?: ""
        val prompt = """
            惑星「${world.name}」に根付く独自の文化を1つ設計してください。
            $langContext
            ヒント: ${hint.ifBlank { "土地の風土と調和した文化" }}
        """.trimIndent()

        return generateJson(prompt, schema).map { json ->
            Culture(
                name = json.optString("name", "新星文化").take(60),
                languageId = language?.id.orEmpty(),
                ethos = json.optString("ethos", "").take(200),
                architectureStyle = json.optString("architectureStyle", "").take(120),
                cuisine = json.optString("cuisine", "").take(120),
                festival = json.optString("festival", "").take(120),
                greeting = json.optString("greeting", "").take(120)
            )
        }
    }

    suspend fun generateReligionAi(world: World, bundle: WorldBundle, hint: String): Result<Religion> {
        val elementContext = bundle.elements.take(3).joinToString("・") { it.name }
        val schema = Schema.obj(
            properties = mapOf(
                "name" to Schema.string("宗教・信仰の名称"),
                "cosmologyType" to Schema.enumeration(listOf("多神教", "一神教", "精霊信仰", "宇宙哲学")),
                "deityConcept" to Schema.string("神格や宇宙観の核（100文字以内）"),
                "tenets" to Schema.string("主な教義・規範（150文字以内）"),
                "rituals" to Schema.string("儀式や祈りの様式（120文字以内）"),
                "creationMyth" to Schema.string("この星の創世神話（260文字以内）"),
                "emblemSides" to Schema.integer("聖印の多角形辺数（3〜10）")
            )
        )
        val prompt = """
            惑星「${world.name}」（存在する元素: ${elementContext.ifBlank { "未知の星素" }}）における宗教・信仰体系と創世神話を生成してください。
            ヒント: ${hint.ifBlank { "星と生命の起源を讃える信仰" }}
        """.trimIndent()

        return generateJson(prompt, schema).map { json ->
            Religion(
                name = json.optString("name", "星辰教").take(60),
                cosmologyType = json.optString("cosmologyType", "多神教").take(40),
                deityConcept = json.optString("deityConcept", "").take(200),
                tenets = json.optString("tenets", "").take(400),
                rituals = json.optString("rituals", "").take(300),
                creationMyth = json.optString("creationMyth", "").take(600),
                emblemSides = json.optLong("emblemSides", 6L).coerceIn(3L, 12L),
                emblemColorHex = 0xFFF4C95DL
            )
        }
    }

    suspend fun generateNationAi(world: World, bundle: WorldBundle, hint: String): Result<Nation> {
        val culture = bundle.cultures.firstOrNull()
        val religion = bundle.religions.firstOrNull()
        val language = bundle.languages.firstOrNull()
        val schema = Schema.obj(
            properties = mapOf(
                "name" to Schema.string("国家名"),
                "governmentType" to Schema.string("政治体制（例: 評議会、王国、自由都市連合など）"),
                "motto" to Schema.string("国の標語（60文字以内）"),
                "diplomacyNote" to Schema.string("外交方針や統治の特徴（140文字以内）")
            )
        )
        val prompt = """
            惑星「${world.name}」に建国された国家を1つ創造してください。
            文化: ${culture?.name ?: "未定"} / 宗教: ${religion?.name ?: "未定"} / 言語: ${language?.name ?: "未定"}
            ヒント: ${hint.ifBlank { "開かれた交易と学術の国家" }}
        """.trimIndent()

        val palette = listOf(0xFF38BDF8L, 0xFFF472B6L, 0xFF34D399L, 0xFFFBBF24L, 0xFFA78BFAL)
        return generateJson(prompt, schema).map { json ->
            Nation(
                name = json.optString("name", "新星連邦").take(60),
                governmentType = json.optString("governmentType", "評議会").take(40),
                cultureId = culture?.id.orEmpty(),
                religionId = religion?.id.orEmpty(),
                languageId = language?.id.orEmpty(),
                colorHex = palette.random(),
                motto = json.optString("motto", "").take(140),
                diplomacyNote = json.optString("diplomacyNote", "").take(300)
            )
        }
    }

    suspend fun generatePersonAi(
        world: World,
        village: Village,
        language: Language?,
        religion: Religion?,
        districtType: DistrictType
    ): Result<Person> {
        val schema = Schema.obj(
            properties = mapOf(
                "name" to Schema.string("現地の言語音韻に合う人物名"),
                "age" to Schema.integer("年齢（16〜80）"),
                "role" to Schema.string("職業や役割（15文字以内）"),
                "traits" to Schema.string("性格・気質（40文字以内）"),
                "biography" to Schema.string("村での生い立ちや功績の短い伝記（200文字以内）")
            )
        )
        val prompt = """
            惑星「${world.name}」の村「${village.name}」（特産: ${village.specialty}）の「${districtType.label}」区画で暮らす住民を1名創造してください。
            使用言語: ${language?.name ?: "共通語"} / 信仰: ${religion?.name ?: "自然信仰"}
        """.trimIndent()

        return generateJson(prompt, schema).map { json ->
            Person(
                villageId = village.id,
                nationId = village.nationId,
                name = json.optString("name", "アレン").take(60),
                age = json.optLong("age", 25L).coerceIn(1L, 1000L),
                role = json.optString("role", districtType.defaultRole).take(50),
                districtType = districtType.key,
                traits = json.optString("traits", "勤勉・好奇心旺盛").take(200),
                faith = religion?.name ?: "星辰の理",
                biography = json.optString("biography", "").take(500)
            )
        }
    }

    suspend fun generateChronicleAi(world: World, bundle: WorldBundle): Result<Chronicle> {
        val schema = Schema.obj(
            properties = mapOf(
                "category" to Schema.enumeration(listOf("創世", "生態", "言語", "文化", "宗教", "文明", "人物")),
                "title" to Schema.string("歴史イベントの見出し（30文字以内）"),
                "summary" to Schema.string("世界年表に刻まれる出来事の詳細（220文字以内）")
            )
        )
        val nations = bundle.nations.joinToString("・") { it.name }.ifBlank { "開拓者たち" }
        val villages = bundle.villages.joinToString("・") { it.name }.ifBlank { "最初の集落" }
        val prompt = """
            惑星「${world.name}」の現在年（${world.eraName} ${world.currentYear}年）に起きた重要な歴史的出来事を1つ創作してください。
            国家: $nations / 村: $villages
        """.trimIndent()

        return generateJson(prompt, schema).map { json ->
            Chronicle(
                year = world.currentYear,
                category = json.optString("category", "文明").take(40),
                title = json.optString("title", "新たな転機").take(80),
                summary = json.optString("summary", "").take(500)
            )
        }
    }
}
