package com.example.engine

import com.example.model.BiomeType
import com.example.model.Chronicle
import com.example.model.Culture
import com.example.model.DistrictCell
import com.example.model.DistrictType
import com.example.model.Ecosystem
import com.example.model.GlyphDefinition
import com.example.model.GlyphPoint
import com.example.model.Language
import com.example.model.Nation
import com.example.model.Person
import com.example.model.Religion
import com.example.model.Species
import com.example.model.Village
import com.example.model.World
import com.example.model.WorldBundle
import com.example.model.WorldCodecs
import com.example.model.WorldElement
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

object ProceduralGenerator {

    fun generatePlanetTerrain(width: Int, height: Int, seed: Long): List<Long> {
        val rng = Random(seed)
        val phaseX = rng.nextDouble(0.0, 6.28)
        val phaseY = rng.nextDouble(0.0, 6.28)
        val tiles = ArrayList<Long>(width * height)

        for (y in 0 until height) {
            for (x in 0 until width) {
                val nx = x.toDouble() / width
                val ny = y.toDouble() / height
                val continent = sin(nx * 5.2 + phaseX) * cos(ny * 4.5 + phaseY) +
                    0.45 * sin(nx * 11.0 - phaseY) +
                    rng.nextDouble(-0.18, 0.18)
                val latTemp = 1.0 - kotlin.math.abs(ny - 0.5) * 2.0
                val moisture = 0.5 + 0.5 * cos(nx * 7.0 + ny * 3.0 + phaseX)

                val biome = when {
                    continent < -0.55 -> BiomeType.DEEP_OCEAN
                    continent < -0.18 -> BiomeType.SHALLOW_SEA
                    continent < -0.05 -> BiomeType.COAST
                    latTemp < 0.22 -> BiomeType.TUNDRA
                    continent > 0.78 -> if (rng.nextFloat() < 0.3f) BiomeType.VOLCANIC else BiomeType.MOUNTAIN
                    continent > 0.55 -> BiomeType.MOUNTAIN
                    moisture < 0.30 -> BiomeType.DESERT
                    moisture > 0.78 && rng.nextFloat() < 0.22f -> BiomeType.CRYSTAL_REEF
                    moisture > 0.52 -> BiomeType.FOREST
                    else -> BiomeType.PLAINS
                }
                val elev = (biome.defaultElevation + rng.nextInt(-6, 7)).coerceIn(5, 98)
                tiles.add(WorldCodecs.encodeTile(biome, elev))
            }
        }
        return tiles
    }

    fun generateElement(
        index: Int = Random.nextInt(1, 140),
        customName: String? = null,
        customSymbol: String? = null,
        customCategory: String? = null,
        atomic: Long? = null,
        colorHex: Long? = null
    ): WorldElement {
        val prefixes = listOf("星輝", "蒼穹", "紅蓮", "深淵", "翡翠", "白銀", "虚無", "琥珀", "雷光", "潮風")
        val suffixes = listOf("鉄", "晶", "素", "石", "霧", "金", "銀", "焔", "露", "核")
        val cats = listOf("金属", "結晶", "気体", "霊素", "鉱物", "流体")
        val palette = listOf(0xFFF4C95DL, 0xFF38BDF8L, 0xFF34D399L, 0xFFF87171L, 0xFFA78BFAL, 0xFFFB923CL)

        val name = customName ?: "${prefixes.random()}${suffixes.random()}"
        val sym = customSymbol ?: "${('A'..'Z').random()}${('a'..'z').random()}"
        val cat = customCategory ?: cats.random()
        val num = atomic ?: (index * 7L + Random.nextLong(1, 30)).coerceIn(1L, 999L)
        val vol = Random.nextLong(5, 95)
        val ab = Random.nextLong(15, 98)
        val traitPool = listOf(
            "光を蓄えて夜間に微弱な燐光を放つ",
            "他の元素と結合すると極めて高い強度を得る",
            "温度変化で気体と結晶を可逆的に行き来する",
            "微細な振動に共鳴し音響通信に用いられる",
            "生命の代謝を活性化させる触媒として働く"
        )
        return WorldElement(
            name = name,
            symbol = sym,
            atomicNumber = num,
            category = cat,
            volatility = vol,
            abundance = ab,
            colorHex = colorHex ?: palette.random(),
            traits = traitPool.random(),
            compoundFormula = ""
        )
    }

    fun synthesizeCompound(a: WorldElement, b: WorldElement): WorldElement {
        val sym = "${a.symbol.take(2)}${b.symbol.take(2)}"
        val formula = "${a.symbol}₂${b.symbol}"
        val blendedColor = ((a.colorHex and 0x00FEFEFEL) + (b.colorHex and 0x00FEFEFEL)) / 2L or 0xFF000000L
        return WorldElement(
            name = "${a.name.take(2)}${b.name.takeLast(2)}合金",
            symbol = sym.take(6),
            atomicNumber = ((a.atomicNumber + b.atomicNumber) / 2L).coerceIn(1L, 999L),
            category = "複合素材",
            volatility = ((a.volatility + b.volatility) / 2L).coerceIn(0L, 100L),
            abundance = minOf(a.abundance, b.abundance),
            colorHex = blendedColor,
            traits = "${a.name}と${b.name}の性質を併せ持つ新素材。建築や祭具・鍛冶に用いられる。",
            compoundFormula = formula.take(80)
        )
    }

    fun generateEcosystem(
        customName: String? = null,
        biome: String = BiomeType.entries.filter { it.code >= 2 }.random().label,
        climate: String = listOf("温暖湿潤", "乾燥大陸性", "亜寒帯", "海洋性", "高地冷涼").random(),
        keyResource: String = "星輝鉄"
    ): Ecosystem {
        val adj = listOf("碧玉の", "霧深い", "黄金の", "風鳴る", "星降る", "静寂の")
        val noun = listOf("樹海", "大草原", "湿原", "群島", "渓谷", "結晶礁")
        return Ecosystem(
            name = customName ?: "${adj.random()}${noun.random()}",
            biomeType = biome,
            climate = climate,
            stability = Random.nextLong(60, 96),
            foodWebSummary = "太陽・鉱物エネルギーを取り込む生産者を中心に、群れを成す草食種と頂点捕食者が循環を維持。",
            keyResource = keyResource
        )
    }

    fun generateSpecies(
        ecosystemId: String,
        customName: String? = null,
        trophicRole: String = listOf("生産者", "草食", "肉食", "分解者").random()
    ): Species {
        val prefixes = listOf("蒼翼", "星角", "霧隠", "金鱗", "風走", "結晶", "夜光", "砂潜")
        val beasts = when (trophicRole) {
            "生産者" -> listOf("巨樹", "光苔", "浮遊藻", "星蓮")
            "草食" -> listOf("鹿", "長頸獣", "甲殻牛", "飛魚")
            "肉食" -> listOf("鷲", "影豹", "双尾狼", "空蛇")
            else -> listOf("菌糸群", "硝子虫", "砂甲虫", "星蚯蚓")
        }
        return Species(
            ecosystemId = ecosystemId,
            name = customName ?: "${prefixes.random()}${beasts.random()}",
            trophicRole = trophicRole,
            population = Random.nextLong(200, 5000),
            traits = "環境適応力が高く、季節移動や共生関係を築く",
            appearance = "体表に淡い模様を持ち、生息域の色調に溶け込む姿"
        )
    }

    fun generateLanguageAndScript(
        customName: String? = null,
        customScriptName: String? = null
    ): Language {
        val rootNames = listOf("ソラリス", "アルカ", "ヴェリア", "ルミナ", "カレド", "ミストル", "エオリア", "タルス")
        val vowels = listOf("a,e,i,o,u", "a,i,u,o", "a,e,i,o,u,ae", "e,i,o,u,ya").random()
        val consonants = listOf("k,s,t,n,r,l,m", "p,t,k,v,s,z,r", "h,m,n,l,w,y,s", "g,d,b,r,l,n,th").random()
        val vList = vowels.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        val cList = consonants.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        val wordOrder = listOf("SOV", "SVO", "VSO").random()
        val pattern = listOf("CV", "CVC", "CVV").random()
        val dir = listOf("LTR", "RTL", "TTB").random()

        val meanings = listOf("星", "空", "水", "大地", "火", "村", "人", "光", "心", "記録")
        val lexicon = meanings.map { meaning ->
            val word = coinWord(vList, cList, pattern, syllables = Random.nextInt(2, 4))
            WorldCodecs.encodeLexiconEntry(word, meaning)
        }

        val glyphKeys = (vList + cList.take(8)).distinct().take(14)
        val glyphs = glyphKeys.map { key ->
            WorldCodecs.encodeGlyph(generateProceduralGlyph(key))
        }

        val sampleWords = lexicon.take(3).map { WorldCodecs.decodeLexiconEntry(it).first }
        return Language(
            name = customName ?: "${rootNames.random()}語",
            wordOrder = wordOrder,
            vowels = vowels,
            consonants = consonants,
            syllablePattern = pattern,
            scriptName = customScriptName ?: "${rootNames.random()}文字",
            scriptType = listOf("音素文字", "音節文字", "表意文字").random(),
            writingDirection = dir,
            lexiconEntries = lexicon,
            glyphStrokes = glyphs,
            sampleSentence = sampleWords.joinToString(" ")
        )
    }

    fun coinWord(
        vowels: List<String>,
        consonants: List<String>,
        pattern: String = "CV",
        syllables: Int = 2
    ): String {
        val sb = StringBuilder()
        repeat(syllables.coerceIn(1, 4)) {
            val c = consonants.randomOrNull() ?: "s"
            val v = vowels.randomOrNull() ?: "a"
            when (pattern) {
                "CVC" -> {
                    val c2 = consonants.randomOrNull() ?: "n"
                    sb.append(c).append(v).append(if (Random.nextBoolean()) c2 else "")
                }
                "CVV" -> sb.append(c).append(v).append(vowels.randomOrNull() ?: "i")
                else -> sb.append(c).append(v)
            }
        }
        return sb.toString()
    }

    fun generateProceduralGlyph(symbolKey: String): GlyphDefinition {
        val seed = symbolKey.hashCode().toLong() + System.nanoTime() % 97
        val rng = Random(seed)
        val strokeCount = rng.nextInt(2, 4)
        val strokes = (0 until strokeCount).map {
            val ptsCount = rng.nextInt(2, 5)
            (0 until ptsCount).map {
                GlyphPoint(
                    x = (rng.nextFloat() * 0.72f + 0.14f),
                    y = (rng.nextFloat() * 0.72f + 0.14f)
                )
            }
        }
        return GlyphDefinition(symbolKey, strokes)
    }

    fun generateCulture(customName: String? = null, languageId: String = ""): Culture {
        val names = listOf("星詠み文化", "風織の民", "潮風海洋文化", "炉火職人文化", "森守の習俗", "白亜学究文化")
        return Culture(
            name = customName ?: names.random(),
            languageId = languageId,
            ethos = listOf("観測と共生", "探求と交易", "職人の誇り", "自然との調和", "記録と継承").random(),
            architectureStyle = listOf("円形石造と星見塔", "木組みの高床回廊", "結晶ガラスの尖塔", "段丘状の白壁集落").random(),
            cuisine = listOf("香草焼きパンと星露茶", "燻製魚と果実酒", "発酵穀物粥と木の実", "香辛料スープと焼き根菜").random(),
            festival = listOf("双星祭", "種蒔きの夜", "灯籠流し", "収穫の輪舞", "文字開きの日").random(),
            greeting = listOf("星に幸あれ", "良き風と歩みを", "光を分かち合おう", "今日が穏やかでありますように").random()
        )
    }

    fun generateReligion(customName: String? = null, elementHint: String = "星輝鉄"): Religion {
        val names = listOf("星辰教", "大樹精霊信仰", "調和の理", "暁光宗", "潮汐の誓い")
        val palette = listOf(0xFFF4C95DL, 0xFFA78BFAL, 0xFF5EEAD4L, 0xFFF97316L, 0xFF60A5FAL)
        return Religion(
            name = customName ?: names.random(),
            cosmologyType = listOf("多神教", "一神教", "精霊信仰", "宇宙哲学").random(),
            deityConcept = "天体と大地を結び、万物の循環を見守る存在",
            tenets = "命と土地を尊び、言葉を偽らず、知識を次世代へ渡す",
            rituals = "季節の変わり目に広場へ集い、灯火と歌を捧げる",
            creationMyth = "原初の空から降り注いだ${elementHint}が海を冷やし、最初の鼓動を大地に与えたと伝えられる。",
            emblemSides = Random.nextLong(3, 9),
            emblemColorHex = palette.random()
        )
    }

    fun generateNation(
        customName: String? = null,
        cultureId: String = "",
        religionId: String = "",
        languageId: String = ""
    ): Nation {
        val prefixes = listOf("アルカディア", "セレニア", "ヴァルハ", "イリス", "ノヴァ", "エルディア")
        val forms = listOf("連邦", "王国", "評議国", "自由都市同盟", "神権領", "共和国")
        val colors = listOf(0xFF38BDF8L, 0xFFF472B6L, 0xFF34D399L, 0xFFFBBF24L, 0xFFA78BFAL, 0xFFFB7185L)
        return Nation(
            name = customName ?: "${prefixes.random()}${forms.random()}",
            governmentType = listOf("賢人評議会", "立憲君主制", "自由都市連合", "神官合議制", "ギルド共和制").random(),
            cultureId = cultureId,
            religionId = religionId,
            languageId = languageId,
            colorHex = colors.random(),
            motto = listOf("星を仰ぎ、土を守る", "自由なる航路と知恵", "共に耕し、共に謳う", "秩序の中に光あり").random(),
            diplomacyNote = "近隣集落との交易と学術交流を重視している。"
        )
    }

    fun generateVillage(
        customName: String? = null,
        nationId: String = "",
        mapX: Long = 5L,
        mapY: Long = 5L
    ): Village {
        val names = listOf("ルミナ", "ミナト", "ヒカリノ", "カゼミ", "アオバ", "ホシヅキ", "イワト", "ユウナギ")
        val initialDistricts = listOf(
            DistrictCell(2, 2, DistrictType.PLAZA, 1, "中央広場"),
            DistrictCell(1, 2, DistrictType.RESIDENTIAL, 1, "東住宅街"),
            DistrictCell(2, 3, DistrictType.FARM, 1, "恵みの農園"),
            DistrictCell(3, 2, DistrictType.SCRIPTORIUM, 1, "星象書院")
        ).map { WorldCodecs.encodeDistrictCell(it) }

        return Village(
            nationId = nationId,
            name = customName ?: "${names.random()}村",
            mapX = mapX,
            mapY = mapY,
            population = Random.nextLong(80, 480),
            prosperity = Random.nextLong(40, 80),
            specialty = listOf("天体観測と製鉄", "織物と薬草", "文字記録と交易", "漁業と造船", "果実酒と陶芸").random(),
            districtCells = initialDistricts
        )
    }

    fun generatePerson(
        villageId: String,
        nationId: String,
        language: Language?,
        faithName: String = "星辰の理",
        districtType: DistrictType = DistrictType.entries.random()
    ): Person {
        val vowels = language?.vowels?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() } ?: listOf("a", "e", "i", "o", "u")
        val consonants = language?.consonants?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() } ?: listOf("k", "s", "t", "n", "r", "l")
        val pattern = language?.syllablePattern ?: "CV"

        val first = coinWord(vowels, consonants, pattern, 2).replaceFirstChar { it.uppercase() }
        val last = coinWord(vowels, consonants, pattern, 2).replaceFirstChar { it.uppercase() }
        val traits = listOf("好奇心旺盛", "温厚", "几帳面", "大胆", "思慮深い", "器用", "詩人肌").shuffled().take(2).joinToString("・")

        return Person(
            villageId = villageId,
            nationId = nationId,
            name = "$first・$last",
            age = Random.nextLong(16, 68),
            role = districtType.defaultRole,
            districtType = districtType.key,
            traits = traits,
            faith = faithName.ifBlank { "星辰の理" },
            biography = "${districtType.label}で${districtType.defaultRole}として暮らし、地域の記録と発展に力を注いでいる。"
        )
    }

    data class SimulationStepResult(
        val newYear: Long,
        val updatedVillages: List<Village>,
        val generatedChronicle: Chronicle?
    )

    fun simulateYears(world: World, bundle: WorldBundle, yearsDelta: Long): SimulationStepResult {
        val nextYear = (world.currentYear + yearsDelta).coerceAtMost(100_000_000L)
        val updatedVillages = bundle.villages.map { v ->
            val growthRate = 1.0 + (yearsDelta.coerceAtMost(100) * 0.015) + (v.prosperity / 1000.0)
            val newPop = (v.population * growthRate).toLong().coerceIn(20L, 9_999_999L)
            val newProsperity = (v.prosperity + Random.nextLong(-2, 6)).coerceIn(10L, 100L)
            v.copy(population = newPop, prosperity = newProsperity)
        }

        val chronicle = if (yearsDelta >= 5 || Random.nextFloat() < 0.45f) {
            val vilName = bundle.villages.randomOrNull()?.name ?: world.name
            val natName = bundle.nations.randomOrNull()?.name ?: "諸部族"
            val elName = bundle.elements.randomOrNull()?.name ?: "未知の鉱脈"
            val langName = bundle.languages.randomOrNull()?.name ?: "古語"
            val events = listOf(
                Triple("文明", "${vilName}の区画拡張", "${natName}の支援を受け、${vilName}で新たな工房と市場が整備された。"),
                Triple("言語", "${langName}の標準辞書編纂", "${vilName}の書記院が各地の言葉を集め、新たな音韻と文字用例をまとめた。"),
                Triple("元素", "${elName}の新鉱脈発見", "地質調査により良質な${elName}が採掘され、道具と建築技術が飛躍した。"),
                Triple("生態", "季節の回遊と豊穣", "生態系の調和が保たれ、多くの新芽と動物たちが大陸を潤した。")
            )
            val chosen = events.random()
            Chronicle(
                userId = world.userId,
                worldId = world.id,
                year = nextYear,
                category = chosen.first,
                title = chosen.second,
                summary = chosen.third
            )
        } else null

        return SimulationStepResult(nextYear, updatedVillages, chronicle)
    }
}
