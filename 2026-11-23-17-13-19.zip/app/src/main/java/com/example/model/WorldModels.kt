package com.example.model

import androidx.annotation.Keep
import com.example.ui.theme.VisualThemeMode
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

enum class GenerationMode(val displayName: String, val shortLabel: String) {
    PROCEDURAL("法則生成", "法則"),
    AI("AI創世 (Gemini)", "AI")
}

enum class BiomeType(
    val code: Int,
    val label: String,
    val defaultElevation: Int,
    val defaultColor: Long
) {
    DEEP_OCEAN(0, "深海", 12, 0xFF0E2954),
    SHALLOW_SEA(1, "浅瀬", 28, 0xFF1F6E8C),
    COAST(2, "砂浜", 40, 0xFFE3C98B),
    PLAINS(3, "草原", 52, 0xFF6AB04C),
    FOREST(4, "森林", 60, 0xFF2D6A4F),
    DESERT(5, "砂漠", 55, 0xFFD99B52),
    MOUNTAIN(6, "山岳", 82, 0xFF7D8597),
    TUNDRA(7, "氷雪", 68, 0xFFCDE7F0),
    VOLCANIC(8, "火山", 90, 0xFFB83B28),
    CRYSTAL_REEF(9, "結晶地帯", 64, 0xFF8B5CF6);

    companion object {
        fun fromCode(code: Int): BiomeType = entries.firstOrNull { it.code == code } ?: PLAINS
    }
}

enum class DistrictType(
    val key: String,
    val label: String,
    val defaultRole: String,
    val colorHex: Long
) {
    RESIDENTIAL("RESIDENTIAL", "住居区", "住民", 0xFF60A5FA),
    MARKET("MARKET", "市場", "商人", 0xFFF59E0B),
    TEMPLE("TEMPLE", "神殿", "神官", 0xFFC084FC),
    SCRIPTORIUM("SCRIPTORIUM", "文字書院", "書記官", 0xFF34D399),
    FORGE("FORGE", "鍛冶・鉱山", "鍛冶師", 0xFFF87171),
    FARM("FARM", "農園・牧場", "農夫", 0xFFA3E635),
    HARBOR("HARBOR", "港湾・門", "航海士", 0xFF2DD4BF),
    PLAZA("PLAZA", "中央広場", "評議員", 0xFFFBBF24);

    companion object {
        fun fromKey(key: String): DistrictType = entries.firstOrNull { it.key == key } ?: RESIDENTIAL
    }
}

data class DistrictCell(
    val x: Int,
    val y: Int,
    val type: DistrictType,
    val level: Int,
    val label: String
)

data class GlyphPoint(val x: Float, val y: Float)

data class GlyphDefinition(
    val symbolKey: String,
    val strokes: List<List<GlyphPoint>>
)

object WorldCodecs {
    fun encodeTile(biome: BiomeType, elevation: Int = biome.defaultElevation): Long {
        val clampedElev = elevation.coerceIn(0, 99)
        return (biome.code * 100 + clampedElev).toLong()
    }

    fun decodeBiome(tileCode: Long): BiomeType {
        val code = (tileCode / 100L).toInt().coerceIn(0, BiomeType.entries.lastIndex)
        return BiomeType.fromCode(code)
    }

    fun decodeElevation(tileCode: Long): Int = (tileCode % 100L).toInt().coerceIn(0, 99)

    fun encodeDistrictCell(cell: DistrictCell): String {
        val cleanLabel = cell.label.replace(":", " ").take(24)
        return "${cell.x},${cell.y}:${cell.type.key}:${cell.level.coerceIn(1, 5)}:$cleanLabel"
    }

    fun decodeDistrictCell(raw: String): DistrictCell? {
        val parts = raw.split(":", limit = 4)
        if (parts.size < 3) return null
        val coords = parts[0].split(",")
        if (coords.size != 2) return null
        val x = coords[0].toIntOrNull()?.coerceIn(0, 5) ?: return null
        val y = coords[1].toIntOrNull()?.coerceIn(0, 5) ?: return null
        val type = DistrictType.fromKey(parts[1])
        val level = parts[2].toIntOrNull()?.coerceIn(1, 5) ?: 1
        val label = parts.getOrNull(3)?.ifBlank { type.label } ?: type.label
        return DistrictCell(x, y, type, level, label)
    }

    fun encodeGlyph(def: GlyphDefinition): String {
        val strokeStr = def.strokes.joinToString(";") { stroke ->
            stroke.joinToString("-") { pt ->
                val rx = (pt.x.coerceIn(0f, 1f) * 100).toInt() / 100f
                val ry = (pt.y.coerceIn(0f, 1f) * 100).toInt() / 100f
                "$rx,$ry"
            }
        }
        return "${def.symbolKey.take(6)}|$strokeStr"
    }

    fun decodeGlyph(raw: String): GlyphDefinition? {
        val idx = raw.indexOf('|')
        if (idx <= 0) return null
        val key = raw.substring(0, idx)
        val body = raw.substring(idx + 1)
        val strokes = if (body.isBlank()) {
            emptyList()
        } else {
            body.split(";").mapNotNull { strokeStr ->
                val pts = strokeStr.split("-").mapNotNull { ptStr ->
                    val xy = ptStr.split(",")
                    if (xy.size != 2) null
                    else {
                        val x = xy[0].toFloatOrNull()
                        val y = xy[1].toFloatOrNull()
                        if (x != null && y != null) GlyphPoint(x.coerceIn(0f, 1f), y.coerceIn(0f, 1f)) else null
                    }
                }
                pts.takeIf { it.isNotEmpty() }
            }
        }
        return GlyphDefinition(key, strokes)
    }

    fun encodeLexiconEntry(word: String, meaning: String): String =
        "${word.replace("=", "-").trim()}=${meaning.replace("=", "-").trim()}"

    fun decodeLexiconEntry(raw: String): Pair<String, String> {
        val idx = raw.indexOf('=')
        return if (idx > 0) {
            raw.substring(0, idx).trim() to raw.substring(idx + 1).trim()
        } else {
            raw.trim() to ""
        }
    }
}

@Keep
@IgnoreExtraProperties
data class World(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val starType: String = "主系列G型星",
    val description: String = "",
    val currentYear: Long = 1L,
    val eraName: String = "創世紀",
    val gridWidth: Long = 16L,
    val gridHeight: Long = 12L,
    val terrainTiles: List<Long> = emptyList(),
    val nationGrid: List<String> = emptyList(),
    val visualTheme: String = VisualThemeMode.CELESTIAL_ASTROLABE.name,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun themeMode(): VisualThemeMode =
        VisualThemeMode.entries.firstOrNull { it.name == visualTheme }
            ?: VisualThemeMode.CELESTIAL_ASTROLABE
}

@Keep
@IgnoreExtraProperties
data class WorldElement(
    @DocumentId val id: String = "",
    val userId: String = "",
    val worldId: String = "",
    val name: String = "",
    val symbol: String = "",
    val atomicNumber: Long = 1L,
    val category: String = "基礎元素",
    val volatility: Long = 20L,
    val abundance: Long = 50L,
    val colorHex: Long = 0xFFF4C95DL,
    val traits: String = "",
    val compoundFormula: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Ecosystem(
    @DocumentId val id: String = "",
    val userId: String = "",
    val worldId: String = "",
    val name: String = "",
    val biomeType: String = BiomeType.PLAINS.label,
    val climate: String = "温暖",
    val stability: Long = 80L,
    val foodWebSummary: String = "",
    val keyResource: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Species(
    @DocumentId val id: String = "",
    val userId: String = "",
    val worldId: String = "",
    val ecosystemId: String = "",
    val name: String = "",
    val trophicRole: String = "生産者",
    val population: Long = 500L,
    val traits: String = "",
    val appearance: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Language(
    @DocumentId val id: String = "",
    val userId: String = "",
    val worldId: String = "",
    val name: String = "",
    val wordOrder: String = "SOV",
    val vowels: String = "a,e,i,o,u",
    val consonants: String = "k,s,t,n,r,m,l",
    val syllablePattern: String = "CV",
    val scriptName: String = "",
    val scriptType: String = "音素文字",
    val writingDirection: String = "LTR",
    val lexiconEntries: List<String> = emptyList(),
    val glyphStrokes: List<String> = emptyList(),
    val sampleSentence: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Culture(
    @DocumentId val id: String = "",
    val userId: String = "",
    val worldId: String = "",
    val name: String = "",
    val languageId: String = "",
    val ethos: String = "",
    val architectureStyle: String = "",
    val cuisine: String = "",
    val festival: String = "",
    val greeting: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Religion(
    @DocumentId val id: String = "",
    val userId: String = "",
    val worldId: String = "",
    val name: String = "",
    val cosmologyType: String = "多神教",
    val deityConcept: String = "",
    val tenets: String = "",
    val rituals: String = "",
    val creationMyth: String = "",
    val emblemSides: Long = 6L,
    val emblemColorHex: Long = 0xFFF4C95DL,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Nation(
    @DocumentId val id: String = "",
    val userId: String = "",
    val worldId: String = "",
    val name: String = "",
    val governmentType: String = "評議会",
    val cultureId: String = "",
    val religionId: String = "",
    val languageId: String = "",
    val colorHex: Long = 0xFF38BDF8L,
    val motto: String = "",
    val diplomacyNote: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Village(
    @DocumentId val id: String = "",
    val userId: String = "",
    val worldId: String = "",
    val nationId: String = "",
    val name: String = "",
    val mapX: Long = 0L,
    val mapY: Long = 0L,
    val population: Long = 120L,
    val prosperity: Long = 50L,
    val specialty: String = "",
    val districtCells: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Person(
    @DocumentId val id: String = "",
    val userId: String = "",
    val worldId: String = "",
    val villageId: String = "",
    val nationId: String = "",
    val name: String = "",
    val age: Long = 24L,
    val role: String = "開拓者",
    val districtType: String = DistrictType.RESIDENTIAL.key,
    val traits: String = "",
    val faith: String = "",
    val biography: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Chronicle(
    @DocumentId val id: String = "",
    val userId: String = "",
    val worldId: String = "",
    val year: Long = 1L,
    val category: String = "創世",
    val title: String = "",
    val summary: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

data class WorldBundle(
    val world: World = World(),
    val elements: List<WorldElement> = emptyList(),
    val ecosystems: List<Ecosystem> = emptyList(),
    val species: List<Species> = emptyList(),
    val languages: List<Language> = emptyList(),
    val cultures: List<Culture> = emptyList(),
    val religions: List<Religion> = emptyList(),
    val nations: List<Nation> = emptyList(),
    val villages: List<Village> = emptyList(),
    val people: List<Person> = emptyList(),
    val chronicles: List<Chronicle> = emptyList()
)
