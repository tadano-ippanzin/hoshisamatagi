package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.core.ThemePreferences
import com.example.core.attemptAutoSignIn
import com.example.core.authStateFlow
import com.example.core.configureAppCheck
import com.example.core.signOut
import com.example.data.WorldRepository
import com.example.engine.AiWorldGenerator
import com.example.model.GenerationMode
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.SandboxWorkspaceScreen
import com.example.ui.screens.WorldsHubScreen
import com.example.ui.theme.HoshitsumugiTheme
import com.example.ui.theme.VisualThemeMode
import com.example.ui.viewmodel.SandboxViewModel
import com.example.ui.viewmodel.WorldsListViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configure Firebase App Check with launch intent before setContent / ViewModels
        configureAppCheck(this, intent)
        enableEdgeToEdge()

        setContent {
            HoshitsumugiAppRoot()
        }
    }
}

@Composable
fun HoshitsumugiAppRoot() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember(context) { ThemePreferences(context.applicationContext) }
    val themeMode by prefs.visualThemeFlow.collectAsStateWithLifecycle(
        initialValue = VisualThemeMode.CELESTIAL_ASTROLABE
    )
    val generationMode by prefs.generationModeFlow.collectAsStateWithLifecycle(
        initialValue = GenerationMode.PROCEDURAL
    )

    val auth = remember { Firebase.auth }
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val credentialManager = remember(context) { CredentialManager.create(context) }

    LaunchedEffect(Unit) {
        if (auth.currentUser == null) {
            attemptAutoSignIn(
                context = context,
                credentialManager = credentialManager,
                onAuthSuccess = {},
                onUnauthenticated = {},
                scope = scope
            )
        }
    }

    HoshitsumugiTheme(themeMode = themeMode) {
        val user = currentUser
        if (user == null) {
            AuthScreen(
                themeMode = themeMode,
                onSelectTheme = { nextTheme ->
                    scope.launch { prefs.setVisualTheme(nextTheme) }
                },
                onAuthSuccess = {}
            )
        } else {
            val uid = user.uid
            key(uid) {
                AuthenticatedAppContent(
                    currentUserId = uid,
                    themeMode = themeMode,
                    generationMode = generationMode,
                    onSelectTheme = { nextTheme ->
                        scope.launch { prefs.setVisualTheme(nextTheme) }
                    },
                    onSelectGenerationMode = { nextMode ->
                        scope.launch { prefs.setGenerationMode(nextMode) }
                    },
                    onSignOut = {
                        signOut(credentialManager, scope)
                    }
                )
            }
        }
    }
}

@Composable
private fun AuthenticatedAppContent(
    currentUserId: String,
    themeMode: VisualThemeMode,
    generationMode: GenerationMode,
    onSelectTheme: (VisualThemeMode) -> Unit,
    onSelectGenerationMode: (GenerationMode) -> Unit,
    onSignOut: () -> Unit
) {
    var activeWorldId by rememberSaveable(currentUserId) { mutableStateOf<String?>(null) }

    val worldsViewModel: WorldsListViewModel = viewModel(
        key = "worlds_$currentUserId",
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                val dbId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(dbId)
                WorldsListViewModel(WorldRepository(db), currentUserId)
            }
        }
    )

    val worldId = activeWorldId
    if (worldId == null) {
        WorldsHubScreen(
            viewModel = worldsViewModel,
            themeMode = themeMode,
            onSelectTheme = onSelectTheme,
            onOpenWorld = { selectedId -> activeWorldId = selectedId },
            onSignOut = onSignOut
        )
    } else {
        key(worldId) {
            val sandboxViewModel: SandboxViewModel = viewModel(
                key = "sandbox_${currentUserId}_$worldId",
                factory = viewModelFactory {
                    initializer {
                        val app = checkNotNull(this[APPLICATION_KEY])
                        val dbId = app.getString(R.string.firestore_database_id)
                        val db = FirebaseFirestore.getInstance(dbId)
                        SandboxViewModel(
                            repository = WorldRepository(db),
                            aiGenerator = AiWorldGenerator(),
                            currentUserId = currentUserId,
                            worldId = worldId
                        )
                    }
                }
            )
            SandboxWorkspaceScreen(
                viewModel = sandboxViewModel,
                themeMode = themeMode,
                generationMode = generationMode,
                onSelectTheme = onSelectTheme,
                onSelectGenerationMode = onSelectGenerationMode,
                onBackToWorlds = { activeWorldId = null }
            )
        }
    }
}
