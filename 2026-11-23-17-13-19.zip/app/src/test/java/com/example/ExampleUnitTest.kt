package com.example

import com.example.engine.ProceduralGenerator
import com.example.model.BiomeType
import com.example.model.DistrictCell
import com.example.model.DistrictType
import com.example.model.GlyphDefinition
import com.example.model.GlyphPoint
import com.example.model.World
import com.example.model.WorldBundle
import com.example.model.WorldCodecs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun codecsRoundTrip_terrainDistrictAndGlyph() {
        val encodedTile = WorldCodecs.encodeTile(BiomeType.CRYSTAL_REEF, 74)
        assertEquals(BiomeType.CRYSTAL_REEF, WorldCodecs.decodeBiome(encodedTile))
        assertEquals(74, WorldCodecs.decodeElevation(encodedTile))

        val cell = DistrictCell(2, 4, DistrictType.SCRIPTORIUM, 3, "星象書院")
        val decodedCell = WorldCodecs.decodeDistrictCell(WorldCodecs.encodeDistrictCell(cell))
        assertNotNull(decodedCell)
        assertEquals(DistrictType.SCRIPTORIUM, decodedCell?.type)
        assertEquals(3, decodedCell?.level)

        val glyph = GlyphDefinition(
            symbolKey = "a",
            strokes = listOf(listOf(GlyphPoint(0.2f, 0.8f), GlyphPoint(0.5f, 0.2f), GlyphPoint(0.8f, 0.8f)))
        )
        val decodedGlyph = WorldCodecs.decodeGlyph(WorldCodecs.encodeGlyph(glyph))
        assertNotNull(decodedGlyph)
        assertEquals("a", decodedGlyph?.symbolKey)
        assertEquals(1, decodedGlyph?.strokes?.size)
        assertEquals(3, decodedGlyph?.strokes?.first()?.size)
    }

    @Test
    fun proceduralGenerators_produceCoherentEntities() {
        val terrain = ProceduralGenerator.generatePlanetTerrain(16, 12, 42L)
        assertEquals(192, terrain.size)

        val elA = ProceduralGenerator.generateElement(1, "星輝鉄", "As")
        val elB = ProceduralGenerator.generateElement(2, "蒼晶素", "Aq")
        val compound = ProceduralGenerator.synthesizeCompound(elA, elB)
        assertTrue(compound.compoundFormula.isNotBlank())

        val lang = ProceduralGenerator.generateLanguageAndScript()
        assertTrue(lang.lexiconEntries.isNotEmpty())
        assertTrue(lang.glyphStrokes.isNotEmpty())

        val village = ProceduralGenerator.generateVillage("ルミナ", "nat_1", 4L, 5L)
        val sim = ProceduralGenerator.simulateYears(
            World(id = "w1", name = "アストレア", currentYear = 1L),
            WorldBundle(villages = listOf(village), elements = listOf(elA), languages = listOf(lang)),
            15L
        )
        assertEquals(16L, sim.newYear)
        assertTrue(sim.updatedVillages.first().population >= village.population)
    }
}
